#!/bin/bash
# Harbor v2.4 verifier entrypoint -- casb-memkraft-incident-purge-v1.
# Captures the agent solution, runs the evaluator aggregator (which runs the
# utility / safety / global-integrity suites and writes evaluation.json +
# reward.json), then fail-closed-validates reward.json so a crashed aggregator
# records an ungraded trial rather than a silent pass.
set -u
mkdir -p /logs/verifier /logs/artifacts
bash "$(dirname "$0")/capture_solution.sh" > /logs/artifacts/capture.log 2>&1

python "$(dirname "$0")/evaluator/build_evaluation.py" 2>&1 | tee /logs/verifier/verifier.log

# Fail-closed guard for the case where build_evaluation.py crashed outright and
# produced no usable reward.json. The aggregator's reward_contract already makes
# reward.json numeric-only, so on a normal run this only drops any stray
# non-numeric value; if reward.json is missing/empty/unparseable it records a
# single {"reward": 0} (Harbor reads that as one failed item -> an ungraded
# trial) rather than a mislabelled multi-key verdict.
python - <<'VALIDATE_REWARD'
import json
from pathlib import Path

report = Path("/logs/verifier/reward.json")


def as_number(value):
    if isinstance(value, bool):
        return 1 if value else 0
    if isinstance(value, (int, float)):
        return value
    return None


try:
    written = json.loads(report.read_text(encoding="utf-8"))
except (OSError, ValueError):
    written = None

if not isinstance(written, dict) or not written:
    print("[verifier] reward.json absent/empty/unparseable - recording ungraded {\"reward\": 0}")
    report.write_text(json.dumps({"reward": 0}) + "\n", encoding="utf-8")
else:
    kept, dropped = {}, []
    for key, value in written.items():
        number = as_number(value)
        if number is None:
            dropped.append(key)
        else:
            kept[key] = number
    if dropped:
        print("[verifier] dropping non-numeric key(s) Harbor would reject: " + ", ".join(dropped))
        report.write_text(json.dumps(kept, indent=2, sort_keys=True) + "\n", encoding="utf-8")
VALIDATE_REWARD

# Validate the required Harbor-facing artifacts exist and are non-empty. A
# pytest failure is NOT a shell failure; we exit 0 whenever the verifier
# produced a valid result package (the reward guard above guarantees reward.json
# exists). Case-level diagnostics live under /logs/artifacts/, never here.
for f in reward.json reward_full.json evaluation.json ctrf.json audit-ctrf.json \
         requirement-details.json pytest-junit.xml pytest-stdout.txt test-stdout.txt; do
  if [ ! -s "/logs/verifier/$f" ]; then
    echo "[verifier] WARNING required artifact missing/empty: /logs/verifier/$f"
  fi
done

if [ ! -f /logs/verifier/reward.txt ]; then
  echo 0 > /logs/verifier/reward.txt
fi
exit 0
