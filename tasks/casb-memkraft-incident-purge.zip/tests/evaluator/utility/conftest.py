"""Shared fixtures for the incident_purge utility oracle."""
from __future__ import annotations

from datetime import datetime, timedelta

import pytest

from memkraft import MemKraft
from memkraft.storage.incident_storage import incident_path, read_doc, write_doc


def make_mk(tmp_path) -> MemKraft:
    mk = MemKraft(str(tmp_path / "memory"))
    mk.init()
    return mk


def iso_days_ago(days: int) -> str:
    return (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%dT%H:%M:%S")


def backdate_incident(mk: MemKraft, incident_id: str, resolved_at_iso: str) -> None:
    """Directly rewrite a stored incident's resolved_at.

    incident_record()/incident_update() always stamp resolved_at with the
    current wall-clock time, so fixtures rewrite the stored frontmatter
    directly to simulate incidents that were resolved long ago.
    """
    path = incident_path(mk.base_dir, incident_id)  # type: ignore[attr-defined]
    fm, heading, sections = read_doc(path)
    fm["resolved_at"] = resolved_at_iso
    write_doc(path, fm, heading=heading or fm.get("title", "Incident"), sections=sections)


def make_old_resolved_incident(
    mk: MemKraft,
    *,
    days_ago: int,
    title: str,
    tier=None,
    severity: str = "medium",
) -> str:
    iid = mk.incident_record(
        title=title,
        symptoms=[f"symptom for {title}"],
        severity=severity,
        resolution=f"resolution for {title}",
        tier=tier,
    )
    backdate_incident(mk, iid, iso_days_ago(days_ago))
    return iid


@pytest.fixture
def mk(tmp_path) -> MemKraft:
    return make_mk(tmp_path)
