"""UTILITY: eligibility is limited to resolved incidents whose resolved_at
is at least older_than_days days in the past; open incidents are never
eligible regardless of age, and recently-resolved incidents are kept."""
from __future__ import annotations

from conftest import backdate_incident, iso_days_ago, make_old_resolved_incident


def test_open_incident_never_purged_even_when_very_old(mk):
    iid = mk.incident_record(
        title="still open ancient",
        symptoms=["never got fixed"],
    )
    backdate_incident(mk, iid, iso_days_ago(3000))
    # an "open" incident has no resolved_at at all; nothing should touch it.

    result = mk.incident_purge(older_than_days=1, dry_run=False)

    assert iid not in result["purged"]
    mk.incident_get(iid)
    assert any(r["id"] == iid for r in mk.incident_search(status="open"))


def test_recently_resolved_incident_is_kept(mk):
    iid = make_old_resolved_incident(mk, days_ago=2, title="just resolved")

    result = mk.incident_purge(older_than_days=30, dry_run=False)

    assert iid not in result["purged"]
    mk.incident_get(iid)


def test_boundary_incident_past_cutoff_is_eligible(mk):
    iid = make_old_resolved_incident(mk, days_ago=31, title="just past cutoff")

    result = mk.incident_purge(older_than_days=30, dry_run=False)

    assert iid in result["purged"]
