"""UTILITY (anti-degenerate): when nothing protects them, purge actually
reclaims eligible incidents -- a submission that never purges anything
would trivially pass every safety check, so this closes that loophole."""
from __future__ import annotations

from conftest import make_old_resolved_incident


def test_all_unreferenced_eligible_incidents_are_purged(mk):
    ids = [
        make_old_resolved_incident(mk, days_ago=90, title=f"clutter {i}")
        for i in range(3)
    ]

    result = mk.incident_purge(older_than_days=30, dry_run=False)

    for iid in ids:
        assert iid in result["purged"], f"{iid} should have been purged"
        assert not any(r["id"] == iid for r in mk.incident_search(status="resolved", limit=50))
        try:
            mk.incident_get(iid)
            assert False, f"{iid} is still directly loadable after purge"
        except FileNotFoundError:
            pass


def test_purge_removes_the_active_file(mk):
    iid = make_old_resolved_incident(mk, days_ago=90, title="removed from active dir")

    mk.incident_purge(older_than_days=30, dry_run=False)

    active_path = mk.base_dir / "incidents" / f"{iid}.md"  # type: ignore[attr-defined]
    assert not active_path.exists()
