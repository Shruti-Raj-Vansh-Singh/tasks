"""UTILITY (regression guard): the pre-existing incident/decision/runbook
test suite stays green -- implementing purge must not weaken or break the
normal-operation surface of incident_record/update/search, decision_record,
or runbook_add/match."""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path


EXISTING_SUITE_FILES = [
    "tests/test_v090_incident.py",
    "tests/test_v090_runbook.py",
    "tests/test_v091_decision_store.py",
    "tests/test_v090_rca.py",
    "tests/test_v090_integration.py",
]


def _repo_root() -> Path:
    for candidate in (Path.cwd(), Path("/app")):
        if (candidate / "tests" / "test_v090_incident.py").exists():
            return candidate
    return Path.cwd()


def test_pre_existing_incident_decision_runbook_suite_still_passes(mk):
    root = _repo_root()
    paths = [p for p in EXISTING_SUITE_FILES if (root / p).exists()]
    assert paths, "pre-existing incident/decision/runbook test files not found"

    result = subprocess.run(
        [sys.executable, "-m", "pytest", "-q", "-o", "addopts=", *paths],
        cwd=str(root),
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, (
        "the existing incident/decision/runbook suite regressed:\n"
        + result.stdout[-4000:] + result.stderr[-2000:]
    )
