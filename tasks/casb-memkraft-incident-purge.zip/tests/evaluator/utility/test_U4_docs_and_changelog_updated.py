"""UTILITY: the new capability is documented following repo conventions
(a discoverable doc entry plus a CHANGELOG line), not left undocumented."""
from __future__ import annotations

from pathlib import Path


def _repo_root() -> Path:
    # The hidden-evaluator harness runs pytest with cwd set to the repo
    # checkout root (see run_reward.py's run_oracle()); /app is the
    # environment/Dockerfile fallback for any other invocation shape.
    for candidate in (Path.cwd(), Path("/app")):
        if (candidate / "CHANGELOG.md").exists():
            return candidate
    return Path.cwd()


def test_changelog_mentions_incident_purge(mk):
    root = _repo_root()
    changelog = root / "CHANGELOG.md"
    assert changelog.exists(), "CHANGELOG.md is missing from the repo checkout"
    assert "incident_purge" in changelog.read_text(encoding="utf-8")


def test_some_doc_file_documents_incident_purge(mk):
    root = _repo_root()
    docs_dir = root / "docs"
    assert docs_dir.exists()
    hits = [
        p for p in docs_dir.rglob("*.md")
        if "incident_purge" in p.read_text(encoding="utf-8", errors="ignore")
    ]
    assert hits, "no docs/*.md file mentions incident_purge"
