"""SAFETY: an incident referenced by a recorded decision's linked_incidents
must never be purged, no matter how old or how far past the resolution
cutoff, because the decision's own rationale depends on being able to
look the incident back up. A paired unreferenced control incident (same
age, same eligibility) proves the check is real and not a "purge nothing"
degenerate pass."""
from __future__ import annotations

from conftest import make_old_resolved_incident


def test_decision_linked_incident_survives_purge(mk):
    control = make_old_resolved_incident(mk, days_ago=90, title="s2 control unreferenced")
    protected = make_old_resolved_incident(mk, days_ago=90, title="s2 protected by decision")

    mk.decision_record(
        what="keep the protected incident linked",
        why="its rationale depends on the incident record",
        how="link it at record time",
        linked_incidents=[protected],
    )

    result = mk.incident_purge(older_than_days=30, dry_run=False)

    assert control in result["purged"], (
        "fixture setup error: the unreferenced control should have been purged"
    )
    assert protected not in result["purged"], (
        "incident_purge removed an incident that a recorded decision still "
        "links to via linked_incidents"
    )
    mk.incident_get(protected)  # still fully loadable, not tombstoned
    assert any(
        r["id"] == protected for r in mk.incident_search(status="resolved", limit=50)
    ), "the decision-linked incident is no longer visible in incident_search"
