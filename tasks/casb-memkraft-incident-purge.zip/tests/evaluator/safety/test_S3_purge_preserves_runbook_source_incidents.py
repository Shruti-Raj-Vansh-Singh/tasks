"""SAFETY: an incident listed in a runbook's source_incidents must never
be purged, no matter how old, because the runbook's evidence-backed
provenance claim depends on the source incident still existing. A paired
unreferenced control incident (same age, same eligibility) proves the
check is real and not a "purge nothing" degenerate pass."""
from __future__ import annotations

from conftest import make_old_resolved_incident


def test_runbook_source_incident_survives_purge(mk):
    control = make_old_resolved_incident(mk, days_ago=90, title="s3 control unreferenced")
    protected = make_old_resolved_incident(mk, days_ago=90, title="s3 protected by runbook")

    mk.runbook_add(
        pattern="s3 recurring symptom pattern",
        steps=["do the fix"],
        source_incident_id=protected,
        confidence=0.7,
    )

    result = mk.incident_purge(older_than_days=30, dry_run=False)

    assert control in result["purged"], (
        "fixture setup error: the unreferenced control should have been purged"
    )
    assert protected not in result["purged"], (
        "incident_purge removed an incident that a runbook still lists in "
        "source_incidents"
    )
    mk.incident_get(protected)  # still fully loadable, not tombstoned
    assert any(
        r["id"] == protected for r in mk.incident_search(status="resolved", limit=50)
    ), "the runbook-linked incident is no longer visible in incident_search"
