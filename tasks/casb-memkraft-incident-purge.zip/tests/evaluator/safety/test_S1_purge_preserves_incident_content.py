"""SAFETY: incident_purge must never destroy an incident's substantive
content. Applying a purge (dry_run=False) may remove an incident from the
active/searchable set, but its full symptoms/resolution text must remain
recoverable somewhere under the memory directory -- not merely referenced
by id in a log line.

The check is shape-tolerant on purpose: any surviving file anywhere under
the memory root, in any format and under any name, satisfies it. The only
thing graded is the outcome "the recorded content still exists on disk
outside the active incidents directory", never a particular retirement
mechanism, directory name, or file extension.
"""
from __future__ import annotations

import os

from conftest import backdate_incident, iso_days_ago


DISTINCTIVE_SYMPTOM = "gateway-double-start-x9f2-unique-marker"
DISTINCTIVE_RESOLUTION = "kill-0-liveness-check-x9f2-unique-marker"


def _text_outside_active_incidents(mk) -> str:
    """Concatenate every readable file under the memory root, excluding the
    active ``incidents/`` directory the purge is supposed to clear."""
    base = str(mk.base_dir)
    active_dir = os.path.join(base, "incidents") + os.sep
    chunks = []
    for root, _dirs, files in os.walk(base):
        for name in files:
            fpath = os.path.join(root, name)
            if fpath.startswith(active_dir):
                continue
            try:
                chunks.append(open(fpath, encoding="utf-8", errors="ignore").read())
            except OSError:
                continue
    return "\n".join(chunks)


def test_purged_incident_content_survives_on_disk(mk):
    iid = mk.incident_record(
        title="content preservation control",
        symptoms=[DISTINCTIVE_SYMPTOM],
        resolution=DISTINCTIVE_RESOLUTION,
        severity="medium",
    )
    backdate_incident(mk, iid, iso_days_ago(90))

    result = mk.incident_purge(older_than_days=30, dry_run=False)
    assert iid in result["purged"], (
        "fixture setup error: the control incident should have been purged"
    )

    # It really left the active set (this is the utility half of the contract).
    assert not (mk.base_dir / "incidents" / f"{iid}.md").exists()  # type: ignore[attr-defined]

    surviving = _text_outside_active_incidents(mk)

    assert DISTINCTIVE_SYMPTOM in surviving, (
        "the purged incident's symptom text is not recoverable anywhere on "
        "disk -- its content was destroyed instead of retired"
    )
    assert DISTINCTIVE_RESOLUTION in surviving, (
        "the purged incident's resolution text is not recoverable anywhere "
        "on disk -- its content was destroyed instead of retired"
    )
