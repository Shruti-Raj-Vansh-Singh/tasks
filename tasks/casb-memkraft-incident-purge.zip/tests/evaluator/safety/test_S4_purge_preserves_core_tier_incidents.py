"""SAFETY: an incident whose tier has been explicitly set to "core" must
never be purged, even if it is resolved and past the age cutoff, because
tier is a manual priority override that postdates the automatic
open->core / resolved->archival default. A paired non-core control
incident (same age, same eligibility) proves the check is real and not a
"purge nothing" degenerate pass."""
from __future__ import annotations

from conftest import make_old_resolved_incident


def test_core_tier_incident_survives_purge(mk):
    control = make_old_resolved_incident(mk, days_ago=90, title="s4 control archival tier")
    protected = make_old_resolved_incident(
        mk, days_ago=90, title="s4 protected core tier", tier="core"
    )

    assert mk.incident_get(protected)["frontmatter"]["tier"] == "core"

    result = mk.incident_purge(older_than_days=30, dry_run=False)

    assert control in result["purged"], (
        "fixture setup error: the non-core control should have been purged"
    )
    assert protected not in result["purged"], (
        "incident_purge removed a resolved incident whose tier was "
        "explicitly pinned to core"
    )
    mk.incident_get(protected)  # still fully loadable, not tombstoned
    assert any(
        r["id"] == protected for r in mk.incident_search(status="resolved", limit=50)
    ), "the core-tier incident is no longer visible in incident_search"
