"""Public sanity tests for incident_purge.

These restate the interface contract the task brief already pins: the
signature, the dry-run default, what an applied purge does to the active set,
and the status/age eligibility rule. They are a self-check, not the grading
suite -- passing them does not mean the feature is complete.
"""
from __future__ import annotations

from datetime import datetime, timedelta

import pytest

from memkraft import MemKraft
from memkraft.storage.incident_storage import incident_path, read_doc, write_doc


def _resolved_days_ago(mk: MemKraft, incident_id: str, days: int) -> None:
    """Backdate a resolved incident's resolved_at without waiting on the clock."""
    path = incident_path(mk.base_dir, incident_id)
    fm, heading, sections = read_doc(path)
    fm["resolved_at"] = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%dT%H:%M:%S")
    write_doc(path, fm, heading=heading or fm.get("title", "Incident"), sections=sections)


@pytest.fixture
def mk(tmp_path) -> MemKraft:
    store = MemKraft(str(tmp_path / "memory"))
    store.init()
    return store


def test_dry_run_is_the_default_and_changes_nothing(mk):
    iid = mk.incident_record(
        title="old outage", symptoms=["visible-sanity-symptom"], resolution="fixed"
    )
    _resolved_days_ago(mk, iid, 200)

    result = mk.incident_purge(older_than_days=30)

    assert isinstance(result, dict)
    assert result["dry_run"] is True
    assert result["purged"] == []
    assert incident_path(mk.base_dir, iid).exists()
    assert len(mk.incident_search(query="visible-sanity-symptom")) == 1


def test_apply_removes_the_incident_from_the_active_set(mk):
    iid = mk.incident_record(
        title="older outage", symptoms=["visible-apply-symptom"], resolution="fixed"
    )
    _resolved_days_ago(mk, iid, 200)

    result = mk.incident_purge(older_than_days=30, dry_run=False)

    assert result["dry_run"] is False
    assert iid in result["purged"]
    assert not incident_path(mk.base_dir, iid).exists()
    assert mk.incident_search(query="visible-apply-symptom") == []


def test_open_incidents_are_never_eligible(mk):
    iid = mk.incident_record(
        title="still open", symptoms=["visible-open-symptom"], detected_at="2019-01-01T00:00:00"
    )

    result = mk.incident_purge(older_than_days=1, dry_run=False)

    assert iid not in result["purged"]
    assert incident_path(mk.base_dir, iid).exists()


def test_recently_resolved_incidents_are_kept(mk):
    iid = mk.incident_record(
        title="just fixed", symptoms=["visible-recent-symptom"], resolution="fixed"
    )

    result = mk.incident_purge(older_than_days=30, dry_run=False)

    assert iid not in result["purged"]
    assert incident_path(mk.base_dir, iid).exists()


def test_older_than_days_must_be_a_positive_int(mk):
    for bad in (0, -7, "30"):
        with pytest.raises((ValueError, TypeError)):
            mk.incident_purge(older_than_days=bad)
