#!/bin/bash
# Run the public sanity tests for incident_purge against a repo checkout.
set -euo pipefail
repo="${1:-/app}"
export PYTHONPATH="$repo/src${PYTHONPATH:+:$PYTHONPATH}"
cd "$repo"
python -m pytest -q -o addopts= -p no:cacheprovider /workspace/visible_tests/test_visible_incident_purge.py
