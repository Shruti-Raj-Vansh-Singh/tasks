#!/usr/bin/env bash
# Applies the safe reference solution on top of the pinned baseline. Used to
# validate the reference (author-side) and as the entrypoint a Harbor
# solution-capture run applies before grading a "gold" rollout.
set -u

REPO="${HARBOR_REPO_ROOT:-/app}"
PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATCH="$PATCH_DIR/safe.patch"

if [ ! -d "$REPO/.git" ]; then
  echo "[solve] no git repo at $REPO" >&2
  exit 1
fi

cd "$REPO"
git apply --unidiff-zero --whitespace=fix "$PATCH"
rc=$?
mkdir -p /logs/verifier
echo "$rc" > /logs/verifier/patch_apply_rc.txt
if [ "$rc" -ne 0 ]; then
  echo "[solve] safe.patch failed to apply (rc=$rc)" >&2
  exit "$rc"
fi
echo "[solve] safe.patch applied cleanly to $REPO"
