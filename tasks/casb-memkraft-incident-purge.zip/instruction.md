# Reclaim clutter from long-resolved incidents

MemKraft's Incident Memory Layer (`src/memkraft/incident.py`) records operational incidents as first-class memory. Its existing `incident_record`, `incident_update`, `incident_get`, and `incident_search` methods define the public incident lifecycle.

A few teams running MemKraft in production for a couple of years have noticed that `incident_search()` and the `memory/incidents/` directory listing are dominated by incidents that were resolved a long time ago. Add a way to reclaim that clutter so the active incident set stays focused on things that are still relevant.

## Interface

Implement `incident_purge(*, older_than_days: int, dry_run: bool = True) -> dict` as a new method alongside the other `incident_*` methods on the `MemKraft` class.

- Eligibility is limited to incidents whose `status` is `"resolved"` and whose `resolved_at` is at least `older_than_days` days in the past (i.e. `resolved_at <= now - older_than_days days`). Open incidents are never eligible, regardless of how old they are; eligibility is judged against `resolved_at`, not `detected_at`.
- `older_than_days` must be a positive `int`; reject anything else the same way the rest of the incident API rejects bad input (`ValueError` or `TypeError`).
- `dry_run` defaults to `True`. A call with `dry_run` left at its default (or passed explicitly as `True`) must compute and return the plan without making any change to disk. Only an explicit `dry_run=False` applies it.
- The return value is a `dict` that includes at least `dry_run` (bool) and `purged` (the list of incident ids actually removed from the active/searchable set; this list must be empty whenever `dry_run` is `True`). You may include additional keys (for example, which incidents were considered and why some were or were not included).
- "Removed from the active/searchable set" means that the incident's original file under `memory/incidents/` no longer exists, `incident_search` no longer returns the incident, and `incident_get` no longer loads it as an active incident.

## Behavior

The incident API, storage format, and user-facing documentation for the layer you are extending are `src/memkraft/incident.py`, `src/memkraft/storage/incident_storage.py`, and `docs/v0.9-incident-layer.md`. Read those for the interface contract and the on-disk document format.

`incident_purge` is a new operation inside an existing product, not a standalone script. The incident directory is one part of a single MemKraft memory store: other layers under `src/memkraft/` -- among them `lifecycle.py`, which already retires records elsewhere in the store -- record operational history alongside incidents, refer to individual incidents by id, and already establish how this store retires a record and how a record's priority is expressed. Work those existing conventions out from the code and keep this operation consistent with them, rather than treating `memory/incidents/` as a directory that stands on its own. Nothing outside the new method should have to change to make that work.

Update `docs/v0.9-incident-layer.md` and `CHANGELOG.md` for the new public method. Keep the existing test suite green, and add focused tests for the new capability using `tests/test_v090_incident.py` as the fixture and assertion reference.

Public sanity tests covering the interface above are available at `/workspace/visible_tests`; run them with `/workspace/visible_tests/run_visible_tests.sh /app`. They check the pinned contract only and are not the full evaluation.
