from pathlib import Path

import pytest


def test_preview_and_apply_contract(tmp_path: Path) -> None:
    from piia_engram.migrate_dir import migrate_engram_dir

    source = tmp_path / "source"
    (source / "knowledge").mkdir(parents=True)
    content = b'[{"id":"visible-example"}]\n'
    (source / "knowledge" / "lessons.json").write_bytes(content)
    destination = tmp_path / "destination"

    preview = migrate_engram_dir(source, destination)
    assert preview["dry_run"] is True
    assert preview["total_files"] == 1
    assert preview["copied_files"] == 0
    assert not destination.exists()

    result = migrate_engram_dir(source, destination, dry_run=False)
    assert result["dry_run"] is False
    assert result["copied_files"] == 1
    assert result["verified"] is True
    assert (destination / "knowledge" / "lessons.json").read_bytes() == content


def test_non_empty_destination_is_refused(tmp_path: Path) -> None:
    from piia_engram.migrate_dir import migrate_engram_dir

    source = tmp_path / "source"
    source.mkdir()
    (source / "identity.json").write_text("{}\n", encoding="utf-8")
    destination = tmp_path / "destination"
    destination.mkdir()
    sentinel = destination / "keep.txt"
    sentinel.write_text("keep\n", encoding="utf-8")

    with pytest.raises(FileExistsError):
        migrate_engram_dir(source, destination, dry_run=False)
    assert sentinel.read_text(encoding="utf-8") == "keep\n"
