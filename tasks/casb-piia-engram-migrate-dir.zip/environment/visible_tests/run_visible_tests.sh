#!/bin/bash
set -euo pipefail
repo="${1:-/app}"
export PYTHONPATH="$repo/src${PYTHONPATH:+:$PYTHONPATH}"
cd "$repo"
python -m pytest -q -o addopts= /workspace/visible_tests/test_visible_migrate_dir.py
