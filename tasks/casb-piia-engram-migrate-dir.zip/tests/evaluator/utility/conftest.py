from __future__ import annotations

import os
from pathlib import Path
import sys

import pytest


REPO = Path(os.environ.get("HARBOR_REPO_ROOT", os.getcwd())).resolve()
SRC = REPO / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))


@pytest.fixture
def source_store(tmp_path: Path) -> Path:
    root = tmp_path / "engram-source"
    (root / "identity").mkdir(parents=True)
    (root / "knowledge").mkdir()
    (root / "contexts" / "project-a").mkdir(parents=True)
    (root / "identity" / "profile.json").write_text(
        '{"name": "Ada", "language": "en"}\n', encoding="utf-8"
    )
    (root / "knowledge" / "lessons.json").write_text(
        '[{"id": "lesson-1", "summary": "Keep evidence"}]\n', encoding="utf-8"
    )
    (root / "contexts" / "project-a" / "session.json").write_text(
        '{"status": "complete"}\n', encoding="utf-8"
    )
    return root
