from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys


REPO = Path(os.environ.get("HARBOR_REPO_ROOT", os.getcwd())).resolve()


def _run_cli(source: Path, *args: str) -> subprocess.CompletedProcess[str]:
    env = dict(os.environ)
    env["ENGRAM_DIR"] = str(source)
    env["ENGRAM_NO_UPDATE_CHECK"] = "1"
    env["PYTHONPATH"] = str(REPO / "src")
    return subprocess.run(
        [
            sys.executable,
            "-c",
            "from piia_engram.setup_wizard import main; main()",
            "migrate-dir",
            *args,
        ],
        cwd=REPO,
        env=env,
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
        timeout=30,
    )


def test_cli_json_defaults_to_preview_and_yes_applies(source_store: Path, tmp_path: Path) -> None:
    destination = tmp_path / "cli-destination"

    preview = _run_cli(source_store, "--to", str(destination), "--json")
    assert preview.returncode == 0, preview.stderr + preview.stdout
    preview_payload = json.loads(preview.stdout)
    assert preview_payload["dry_run"] is True
    assert not destination.exists()

    applied = _run_cli(source_store, "--to", str(destination), "--yes", "--json")
    assert applied.returncode == 0, applied.stderr + applied.stdout
    applied_payload = json.loads(applied.stdout)
    assert applied_payload["dry_run"] is False
    assert applied_payload["verified"] is True
    assert (destination / "knowledge" / "lessons.json").is_file()
