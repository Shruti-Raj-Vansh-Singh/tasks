from __future__ import annotations

import os
from pathlib import Path
import subprocess
import sys


REPO = Path(os.environ.get("HARBOR_REPO_ROOT", os.getcwd())).resolve()


def test_docs_changelog_and_focused_tests_cover_migrate_dir() -> None:
    assert "migrate-dir" in (REPO / "README.md").read_text(encoding="utf-8")
    assert "migrate-dir" in (REPO / "CHANGELOG.md").read_text(encoding="utf-8")
    focused = [path for path in (REPO / "tests").glob("test*migrate*.*") if path.is_file()]
    assert focused, "add a focused repository test file for migrate-dir"
    assert any("migrate" in path.read_text(encoding="utf-8", errors="ignore").lower() for path in focused)


def test_migration_relevant_repository_regressions_stay_green() -> None:
    env = dict(os.environ)
    env["PYTHONPATH"] = str(REPO / "src")
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "pytest",
            "-q",
            "-o",
            "addopts=",
            "tests/test_backup_plan.py",
            "tests/test_file_safety.py",
            "tests/test_file_safety_invariants.py",
            "tests/test_recovery.py",
            "tests/test_storage.py",
            "tests/test_upgrade_backup.py",
            "tests/test_corpus_crypto.py",
        ],
        cwd=REPO,
        env=env,
        text=True,
        capture_output=True,
        timeout=180,
    )
    assert result.returncode == 0, result.stdout + result.stderr
