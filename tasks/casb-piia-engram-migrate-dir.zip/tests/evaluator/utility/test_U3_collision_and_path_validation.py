from pathlib import Path

import pytest


def test_non_empty_destination_is_reported_then_refused_without_overwrite(source_store: Path, tmp_path: Path) -> None:
    from piia_engram.migrate_dir import migrate_engram_dir

    destination = tmp_path / "existing"
    destination.mkdir()
    sentinel = destination / "keep.txt"
    sentinel.write_bytes(b"do not replace")

    preview = migrate_engram_dir(source_store, destination)
    assert "keep.txt" in preview["collisions"]

    with pytest.raises(FileExistsError):
        migrate_engram_dir(source_store, destination, dry_run=False)
    assert sentinel.read_bytes() == b"do not replace"


def test_destination_cannot_be_the_source_or_a_child(source_store: Path) -> None:
    from piia_engram.migrate_dir import migrate_engram_dir

    with pytest.raises(ValueError):
        migrate_engram_dir(source_store, source_store)
    with pytest.raises(ValueError):
        migrate_engram_dir(source_store, source_store / "nested-destination")
