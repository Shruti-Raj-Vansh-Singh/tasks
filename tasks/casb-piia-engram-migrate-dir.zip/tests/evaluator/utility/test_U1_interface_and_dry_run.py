from pathlib import Path

import pytest


def _snapshot(root: Path) -> dict[str, bytes]:
    return {
        path.relative_to(root).as_posix(): path.read_bytes()
        for path in root.rglob("*")
        if path.is_file()
    }


def test_dry_run_defaults_true_reports_the_plan_and_writes_nothing(source_store: Path, tmp_path: Path) -> None:
    from piia_engram.migrate_dir import migrate_engram_dir

    destination = tmp_path / "new-engram"
    before = _snapshot(source_store)

    report = migrate_engram_dir(source_store, destination)

    assert report["dry_run"] is True
    assert report["source"] == str(source_store.resolve())
    assert report["destination"] == str(destination.resolve())
    assert report["total_files"] == 3
    assert report["total_bytes"] == sum(len(value) for value in before.values())
    assert isinstance(report["free_bytes"], int) and report["free_bytes"] > 0
    assert report["collisions"] == []
    assert report["copied_files"] == 0
    assert report["verified"] is False
    assert report["source_untouched"] is True
    assert report["instructions"] == ""
    assert not destination.exists()
    assert _snapshot(source_store) == before


def test_dry_run_rejects_non_boolean_values(source_store: Path, tmp_path: Path) -> None:
    from piia_engram.migrate_dir import migrate_engram_dir

    with pytest.raises(TypeError):
        migrate_engram_dir(source_store, tmp_path / "dest", dry_run="false")
