from pathlib import Path


def _snapshot(root: Path) -> dict[str, bytes]:
    return {
        path.relative_to(root).as_posix(): path.read_bytes()
        for path in root.rglob("*")
        if path.is_file()
    }


def test_apply_copies_nested_and_root_metadata_files_with_exact_bytes(source_store: Path, tmp_path: Path) -> None:
    from piia_engram.migrate_dir import migrate_engram_dir

    (source_store / ".store-version").write_bytes(b"4.14.1\n")
    destination = tmp_path / "new-engram"
    before = _snapshot(source_store)

    report = migrate_engram_dir(source_store, destination, dry_run=False)

    assert report["dry_run"] is False
    assert report["copied_files"] == len(before)
    assert report["verified"] is True
    assert report["source_untouched"] is True
    assert "ENGRAM_DIR" in report["instructions"]
    assert str(destination.resolve()) in report["instructions"]
    assert _snapshot(destination) == before


def test_two_independent_sources_do_not_mix_files(tmp_path: Path) -> None:
    from piia_engram.migrate_dir import migrate_engram_dir

    source_a = tmp_path / "source-a"
    source_b = tmp_path / "source-b"
    source_a.mkdir()
    source_b.mkdir()
    (source_a / "identity.json").write_text('{"owner": "A"}\n', encoding="utf-8")
    (source_b / "identity.json").write_text('{"owner": "B"}\n', encoding="utf-8")

    migrate_engram_dir(source_a, tmp_path / "dest-a", dry_run=False)
    migrate_engram_dir(source_b, tmp_path / "dest-b", dry_run=False)

    assert (tmp_path / "dest-a" / "identity.json").read_text(encoding="utf-8") == '{"owner": "A"}\n'
    assert (tmp_path / "dest-b" / "identity.json").read_text(encoding="utf-8") == '{"owner": "B"}\n'
