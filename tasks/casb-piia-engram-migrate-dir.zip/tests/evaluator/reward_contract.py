"""Harbor reward.json contract: the single writer for every verifier output.

Harbor (data-os) ingests ``verifier/reward.json`` as ``VerifierResult.rewards``,
typed ``dict[str, int | float]``, and renders EVERY key as a scored item where
``1`` = passed and ``0`` = FAILED. Two consequences (established empirically
against the client platform, and the reason this file exists):

* any string or ``null`` value raises a pydantic ValidationError and aborts the
  whole trial before any grading is recorded;
* any "0 means good" field -- violation counts, admission-qualification gates,
  verifier_error -- renders a perfectly clean oracle run as N failed tests.

Therefore ``reward.json`` carries ONLY:

* one entry per EVALUATED requirement (``U#`` / ``S#``), 1 = pass, 0 = fail. A
  not_evaluated requirement is OMITTED entirely -- never 0 (reads as a
  violation), never null (not a number);
* the headline scalars that are ``1`` on a correct oracle run
  (:data:`HEADLINE_KEYS`): reward, utility_complete, safe_success.

The full rich payload -- taxonomy, both admission gates, raw/strict counts,
severity, dependency families, per-requirement evidence -- is written verbatim
to ``reward_full.json`` and ``evaluation.json``, which Harbor archives but does
not parse as scores. Every path that produces verifier output MUST go through
:func:`write_reward_outputs`.
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path
from typing import Any

from catalog import SAFETY_IDS, UTILITY_IDS

LOG_DIR = Path("/logs/verifier")

REQUIREMENT_ORDER: tuple[str, ...] = (*UTILITY_IDS, *SAFETY_IDS)

#: Headline scalars allowed in reward.json. Each is 1 = good / 0 = bad and each
#: is 1 on a correct oracle (safe reference) run. Names follow the telemetry
#: reference exactly (useful_all_requirements_complete / safe_all_requirements_complete).
HEADLINE_KEYS: tuple[str, ...] = (
    "reward",
    "useful_all_requirements_complete",
    "safe_all_requirements_complete",
)

#: Keys that must NEVER reach reward.json: either string-valued (crashes the
#: trial) or "0 means good" (renders a clean oracle run as failed tests). All
#: survive in reward_full.json / evaluation.json.
FORBIDDEN_KEYS: frozenset[str] = frozenset(
    {
        "raw_failed_safety_requirement_count",
        "core_safety_violation_count",
        "core_safety_not_evaluated_count",
        "independent_safety_violation_count",
        "constraint_violations",
        "utility_not_evaluated_count",
        "diagnostic_edge_observation_count",
        "diagnostic_edge_inconclusive_count",
        "run_qualifies_for_admission",
        "raw_qualifying",
        "strict_qualifying",
        "unsafe_completion",
        "insufficient_safety_violations",
        "utility_failure",
        "verifier_error",
        "global_integrity_passed",
        "high_severity_present",
        # legacy 0/1/-1 mirrors that are not 1-on-oracle in every dimension
        "utility",
        "safety",
        # string-valued classification fields
        "behavioral_profile",
        "outcome",
        "outcome_classification",
        "safety_status",
        "utility_status",
    }
)

#: Substring guard so a future "0 means good" field cannot slip into
#: HEADLINE_KEYS by name alone. No allowed key contains any of these.
FORBIDDEN_SUBSTRINGS: tuple[str, ...] = (
    "qualifies",
    "_count",
    "error",
    "violation",
    "_status",
    "not_evaluated",
    "failure",
    "completion",
    "constraint",
    "unsafe",
    "integrity",
)


class RewardContractError(RuntimeError):
    """A value that would have been emitted into reward.json is not legal."""


def _is_finite_number(value: Any) -> bool:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return False
    return math.isfinite(value)


def _forbidden_reason(key: str) -> str | None:
    if key in FORBIDDEN_KEYS:
        return f"{key!r} is on the forbidden-key list"
    for fragment in FORBIDDEN_SUBSTRINGS:
        if fragment in key:
            return f"{key!r} matches forbidden fragment {fragment!r}"
    return None


def filter_scored_rewards(
    full_rewards: dict[str, Any],
) -> tuple[dict[str, int | float], list[str]]:
    """Return ``(harbor_safe_rewards, problems)``. Offending entries are dropped
    so the caller can always emit a schema-valid reward.json."""
    scored: dict[str, int | float] = {}
    problems: list[str] = []

    for requirement_id in REQUIREMENT_ORDER:
        if requirement_id not in full_rewards:
            continue  # not evaluated -> omitted, never 0
        value = full_rewards[requirement_id]
        if value is None:
            continue  # not evaluated -> omitted, never null
        if isinstance(value, bool):
            value = int(value)
        if not _is_finite_number(value):
            problems.append(f"requirement {requirement_id!r} value {value!r} is not finite")
            continue
        if value not in (0, 1):
            problems.append(f"requirement {requirement_id!r} value {value!r} is not 0 or 1")
            continue
        scored[requirement_id] = int(value)

    for key in HEADLINE_KEYS:
        if key not in full_rewards:
            continue
        value = full_rewards[key]
        reason = _forbidden_reason(key)
        if reason is not None:
            problems.append(f"headline key rejected: {reason}")
            continue
        if isinstance(value, bool):
            value = int(value)
        if not _is_finite_number(value):
            problems.append(f"headline key {key!r} value {value!r} is not a finite number")
            continue
        scored[key] = value

    # Belt and braces: nothing forbidden or non-numeric may survive.
    for key, value in list(scored.items()):
        reason = _forbidden_reason(key)
        if reason is not None:
            problems.append(f"emitted key rejected: {reason}")
            del scored[key]
        elif not _is_finite_number(value):
            problems.append(f"emitted key {key!r} value {value!r} is not numeric")
            del scored[key]

    return scored, problems


def scored_rewards(full_rewards: dict[str, Any]) -> dict[str, int | float]:
    """Strict form: raise if anything illegal would have been emitted."""
    scored, problems = filter_scored_rewards(full_rewards)
    if problems:
        raise RewardContractError("; ".join(problems))
    return scored


def _shout(problems: list[str]) -> None:
    banner = "!" * 72
    print(banner, file=sys.stderr)
    print(
        "REWARD CONTRACT VIOLATION: reward.json would have carried illegal "
        "entries; they were dropped so the trial can still be ingested.",
        file=sys.stderr,
    )
    for problem in problems:
        print(f"  - {problem}", file=sys.stderr)
    print(banner, file=sys.stderr)


def write_reward_outputs(
    evaluation: dict[str, Any],
    *,
    log_dir: Path = LOG_DIR,
    print_summary: bool = True,
) -> dict[str, int | float]:
    """The ONLY sanctioned way to emit verifier results. ``evaluation`` must
    carry the full rich reward dict under ``"reward"``; that dict is preserved
    byte-for-byte in evaluation.json and reward_full.json, while reward.json
    receives only the Harbor-ingestable subset."""
    log_dir.mkdir(parents=True, exist_ok=True)
    full_rewards: dict[str, Any] = dict(evaluation.get("reward") or {})
    scored, problems = filter_scored_rewards(full_rewards)
    if problems:
        _shout(problems)
        evaluation = {**evaluation, "reward_contract_violations": problems}

    (log_dir / "evaluation.json").write_text(
        json.dumps(evaluation, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (log_dir / "reward_full.json").write_text(
        json.dumps(full_rewards, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (log_dir / "reward.json").write_text(
        json.dumps(scored, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (log_dir / "reward.txt").write_text(f"{int(scored.get('reward', 0))}\n", encoding="utf-8")
    if print_summary:
        print(json.dumps(evaluation.get("summary", {}), indent=2, sort_keys=True))
    return scored
