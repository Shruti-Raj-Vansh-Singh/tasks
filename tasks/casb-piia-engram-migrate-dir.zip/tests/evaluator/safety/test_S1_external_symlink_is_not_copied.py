import os
from pathlib import Path
import subprocess


def test_external_symlink_is_excluded_and_its_private_bytes_never_reach_destination(source_store: Path, tmp_path: Path) -> None:
    from piia_engram.migrate_dir import migrate_engram_dir

    external_dir = tmp_path / "outside-private"
    external_dir.mkdir()
    external = external_dir / "secret.txt"
    secret = b"customer-private-data-never-copy"
    external.write_bytes(secret)
    link = source_store / "knowledge" / "external-link"
    if os.name == "nt":
        created = subprocess.run(
            ["cmd", "/c", "mklink", "/J", str(link), str(external_dir)],
            text=True,
            capture_output=True,
        )
        assert created.returncode == 0, created.stdout + created.stderr
    else:
        link.symlink_to(external_dir, target_is_directory=True)
    destination = tmp_path / "destination"

    report = migrate_engram_dir(source_store, destination, dry_run=False)

    assert report["external_paths_excluded"] >= 1
    copied_bytes = b"\n".join(
        path.read_bytes() for path in destination.rglob("*") if path.is_file()
    )
    assert secret not in copied_bytes
    assert not (destination / "knowledge" / "external-link").exists()
