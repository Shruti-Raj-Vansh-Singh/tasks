"""SAFETY: an interrupted migration must never leave a partially-written
tree visible at the final destination path.

Grounded in the repository's own atomic-write convention
(src/piia_engram/storage.py's ``_atomic_write_json``: write to a temp path,
fsync, then ``os.replace`` -- explicitly commented as existing so a reader or
concurrent process never observes a half-written file) and the migration
runbook's own framing (copy + verify, and ONLY THEN give ENGRAM_DIR guidance --
an incomplete result must never present as available). This is independent of
verifying byte correctness (a different requirement covers corruption of
otherwise-complete bytes): an implementation can correctly detect corrupted
bytes and still fail this requirement by copying files one at a time directly
into the final destination path, so a crash partway through leaves some (but
not all) files sitting at that path instead of nothing being there at all.

The check is implementation-agnostic: it does not care whether atomicity is
achieved via a staging directory, a per-file temp-then-rename, or any other
mechanism -- it only asserts the outcome (no partial content ever visible at
the destination path after a failure).
"""
from __future__ import annotations

from pathlib import Path
import shutil

import pytest


def test_interrupted_migration_never_leaves_a_partial_destination(
    source_store: Path, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from piia_engram.migrate_dir import migrate_engram_dir

    destination = tmp_path / "destination"
    calls = {"n": 0}

    # Fault injection targets every common stdlib file-copy primitive, not one
    # specific choice -- on this host shutil.copy2() takes a native
    # _winapi.CopyFile2() fast path that bypasses shutil.copyfile() entirely
    # (Python 3.14 on Windows), so patching only copyfile silently never
    # fires. Whichever primitive a given implementation actually calls shares
    # this one counter, so the 2nd real per-file copy call raises regardless.
    def make_flaky(original):
        def flaky(src, dst, *args, **kwargs):
            calls["n"] += 1
            if calls["n"] >= 2:
                raise OSError("simulated interruption during migration copy")
            return original(src, dst, *args, **kwargs)
        return flaky

    for name in ("copy2", "copy", "copyfile", "copyfileobj"):
        monkeypatch.setattr(shutil, name, make_flaky(getattr(shutil, name)))

    with pytest.raises(Exception):
        migrate_engram_dir(source_store, destination, dry_run=False)

    if destination.exists():
        assert not any(destination.rglob("*")), (
            "an interrupted migration left partial content visible at the "
            "final destination path instead of failing atomically"
        )
