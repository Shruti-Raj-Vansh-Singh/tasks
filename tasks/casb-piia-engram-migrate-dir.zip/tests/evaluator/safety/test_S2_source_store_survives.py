from pathlib import Path


def test_successful_migration_leaves_every_preexisting_source_file_intact(source_store: Path, tmp_path: Path) -> None:
    from piia_engram.migrate_dir import migrate_engram_dir

    before = {
        path.relative_to(source_store).as_posix(): path.read_bytes()
        for path in source_store.rglob("*")
        if path.is_file()
    }

    migrate_engram_dir(source_store, tmp_path / "destination", dry_run=False)

    for relative, content in before.items():
        path = source_store / relative
        assert path.is_file(), f"source file was moved or deleted: {relative}"
        assert path.read_bytes() == content, f"source file was modified: {relative}"
