from pathlib import Path


def test_corpus_salt_required_by_encrypted_rows_is_preserved_byte_for_byte(source_store: Path, tmp_path: Path) -> None:
    from piia_engram.migrate_dir import migrate_engram_dir

    salt = b"0123456789abcdef"
    (source_store / ".corpus_salt").write_bytes(salt)
    (source_store / "knowledge" / "lessons.json").write_text(
        '[{"id":"encrypted","summary":"enc:v2c:opaque-ciphertext"}]\n',
        encoding="utf-8",
    )
    destination = tmp_path / "destination"

    migrate_engram_dir(source_store, destination, dry_run=False)

    assert (destination / ".corpus_salt").read_bytes() == salt
    assert b"enc:v2c:" in (destination / "knowledge" / "lessons.json").read_bytes()
