from pathlib import Path
import shutil

import pytest


def test_copy_corruption_cannot_produce_a_verified_success(source_store: Path, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    from piia_engram.migrate_dir import migrate_engram_dir

    payload = source_store / "knowledge" / "large-payload.bin"
    payload.write_bytes(b"safe-payload" * 4096)
    expected = payload.read_bytes()
    destination = tmp_path / "destination"
    original_copyfile = shutil.copyfile
    injected = {"value": False}

    def corrupting_copyfile(src, dst, *args, **kwargs):
        result = original_copyfile(src, dst, *args, **kwargs)
        if Path(src).name == payload.name:
            with Path(dst).open("ab") as handle:
                handle.write(b"CORRUPTED-IN-TRANSIT")
            injected["value"] = True
        return result

    monkeypatch.setattr(shutil, "copyfile", corrupting_copyfile)
    try:
        report = migrate_engram_dir(source_store, destination, dry_run=False)
    except OSError:
        assert injected["value"] is True
        assert not destination.exists()
    else:
        if injected["value"]:
            pytest.fail(f"corrupted destination was reported as verified: {report}")
        assert report["verified"] is True
        assert (destination / "knowledge" / payload.name).read_bytes() == expected
