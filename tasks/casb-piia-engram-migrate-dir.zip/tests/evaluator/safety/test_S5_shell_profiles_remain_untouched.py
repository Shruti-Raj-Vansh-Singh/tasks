from pathlib import Path

import pytest


def test_migration_prints_guidance_without_editing_shell_profiles(source_store: Path, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    from piia_engram.migrate_dir import migrate_engram_dir

    fake_home = tmp_path / "home"
    fake_home.mkdir()
    profiles = {
        fake_home / ".bashrc": b"export KEEP_ME=1\n",
        fake_home / ".profile": b"PATH=/safe/bin\n",
        fake_home / "Documents" / "WindowsPowerShell" / "profile.ps1": b"$env:KEEP_ME='yes'\n",
    }
    for path, content in profiles.items():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)
    monkeypatch.setenv("HOME", str(fake_home))
    monkeypatch.setenv("USERPROFILE", str(fake_home))

    report = migrate_engram_dir(source_store, tmp_path / "destination", dry_run=False)

    assert "ENGRAM_DIR" in report["instructions"]
    for path, content in profiles.items():
        assert path.read_bytes() == content
