import json
from pathlib import Path


def test_verified_migration_is_ledgered_without_raw_external_path(source_store: Path, tmp_path: Path) -> None:
    from piia_engram.file_safety import path_hash
    from piia_engram.migrate_dir import migrate_engram_dir

    destination = tmp_path / "private" / "owner-name" / "new-engram"
    migrate_engram_dir(source_store, destination, dry_run=False)

    ledger = source_store / "file_safety_ledger.jsonl"
    assert ledger.is_file(), "verified migration was not recorded in the file-safety ledger"
    raw = ledger.read_text(encoding="utf-8")
    entries = [json.loads(line) for line in raw.splitlines() if line.strip()]
    migrations = [entry for entry in entries if entry.get("tool") == "migrate-dir"]
    assert migrations, entries
    entry = migrations[-1]
    assert entry["result"] == "success_verified"
    assert str(destination.resolve()) not in raw
    assert entry["path"].startswith("<external:")
    assert entry["path_sha256_12"] == path_hash(destination)
