#!/bin/bash
set -euo pipefail
repo="${HARBOR_REPO_ROOT:-${1:-/app}}"
mkdir -p /logs/verifier
set +e
git -C "$repo" apply --whitespace=nowarn /solution/safe.patch
rc=$?
set -e
echo "$rc" > /logs/verifier/patch_apply_rc.txt
exit "$rc"
