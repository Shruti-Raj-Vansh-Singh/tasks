# Add the ENGRAM_DIR migration command

Piia Engram honors `ENGRAM_DIR`, but moving an established local store to a new disk is still a manual operation. Implement the bounded `migrate-dir` workflow already described by the repository so an owner can preview and then perform that migration from the CLI.

## Library interface

Add `src/piia_engram/migrate_dir.py` with these public functions:

- `plan_engram_dir_migration(source: str | Path, destination: str | Path) -> dict[str, Any]`
- `migrate_engram_dir(source: str | Path, destination: str | Path, *, dry_run: bool = True) -> dict[str, Any]`

Both functions operate on the directory passed as `source`; they must not depend on the process's current `ENGRAM_DIR` value. The return dictionary must contain at least these keys with these meanings:

- `dry_run`: whether this call was a preview.
- `source` and `destination`: resolved path strings.
- `total_files` and `total_bytes`: the count and byte total of the Engram-owned regular files included in the migration.
- `free_bytes`: currently available bytes on the destination filesystem.
- `collisions`: a sorted list of destination-relative paths already present below the destination; use an empty list when there are none.
- `external_paths_excluded`: the number of paths excluded by the repository's Engram-root ownership boundary.
- `copied_files`: zero in a preview and the number copied by a successful apply.
- `verified`: `False` in a preview and `True` only for a successfully completed apply.
- `source_untouched`: `True` when the operation completed without changing the source records being migrated.
- `instructions`: an empty string in a preview and, after success, guidance that names `ENGRAM_DIR` and the resolved destination.

`migrate_engram_dir` defaults to a zero-write preview. Only an explicit `dry_run=False` applies the operation. Reject a non-boolean `dry_run`. Reject a missing source, a destination equal to or nested below the source, and an apply to a non-empty destination. Previewing a non-empty destination must report its collisions without modifying either tree. A successful apply must reproduce the included source files at the destination with identical relative paths and bytes, including root-level metadata files and nested directories.

## CLI and repository integration

Add `engram migrate-dir --to <new_dir> [--dry-run] [--yes] [--json]` to the existing CLI. The default and `--dry-run` forms preview. `--yes` applies. `--json` prints the report dictionary as JSON. This first version does not add force-merge behavior; a non-empty destination is refused on apply.

Use `docs/architecture.md` for the repository layout and CLI integration points. Follow the repository's existing runbooks and filesystem conventions for behavior beyond the interface explicitly defined here.

Document the command in `README.md` and `CHANGELOG.md`, add focused offline tests in the repository's existing pytest style, and keep the migration-relevant existing tests green.

Public sanity tests are available at `/workspace/visible_tests`; run them with `/workspace/visible_tests/run_visible_tests.sh /app`.
