#!/usr/bin/env bash
set -u

OUT=/logs/artifacts/solution
mkdir -p "$OUT/changed"

REPO_ROOT=""
BASE=""
BASE_SOURCE=""
N=0

# Machine-readable outcome for the canvas. Written on every exit path.
write_status() {
  printf '{\n  "ok": %s,\n  "reason": "%s",\n  "repo_root": "%s",\n  "base": "%s",\n  "base_source": "%s",\n  "changed_files": %s\n}\n' \
    "$1" "$2" "${REPO_ROOT:-}" "${BASE:-}" "${BASE_SOURCE:-}" "${N:-0}" > "$OUT/capture_status.json"
}

harbor_repo_root() {
  local candidate
  for candidate in "${HARBOR_REPO_ROOT:-}" "${HARBOR_AGENT_SURFACE:-}" "${REPO_UNDER_TEST:-}"; do
    if [ -n "$candidate" ] && [ -e "$candidate/.git" ]; then
      printf '%s\n' "$candidate"
      return 0
    fi
  done
  for candidate in /app /workspace /repo /src /testbed /code; do
    if [ -e "$candidate/.git" ]; then
      printf '%s\n' "$candidate"
      return 0
    fi
  done
  # One level down -- the common imported-task layout (/workspace/diskcache).
  for candidate in /workspace/*/ /src/*/ /testbed/*/; do
    if [ -e "${candidate%/}/.git" ]; then
      printf '%s\n' "${candidate%/}"
      return 0
    fi
  done
  return 1
}

# Containers commonly run as root over a repo owned by another uid; without
# this every git call below fails with "dubious ownership".
git config --global --add safe.directory '*' 2>/dev/null || true

if ! REPO_ROOT="$(harbor_repo_root)"; then
  echo "[capture] no git repository found -- set HARBOR_REPO_ROOT in the task environment"
  write_status false repo_root_not_found
  exit 0
fi
if ! cd "$REPO_ROOT"; then
  echo "[capture] repository root $REPO_ROOT is not readable"
  write_status false repo_root_unreadable
  exit 0
fi
echo "[capture] repo_root=$REPO_ROOT"

# 1. Stamp written at image build -- the most reliable signal when present.
if [ -f /.harbor_base_commit ]; then
  BASE=$(tr -d '[:space:]' < /.harbor_base_commit)
  BASE_SOURCE=stamp
elif [ -f /harbor_base_commit ]; then
  BASE=$(tr -d '[:space:]' < /harbor_base_commit)
  BASE_SOURCE=stamp
fi

# 2. Clone tip via the tracking branch -- unmoved by agent commits.
if [ -z "${BASE:-}" ]; then
  BASE=$(git rev-parse --verify --quiet "@{upstream}" 2>/dev/null || true)
  [ -n "${BASE:-}" ] && BASE_SOURCE=upstream
fi

# 3. Same idea for a checkout with no configured upstream.
if [ -z "${BASE:-}" ]; then
  BRANCH=$(git rev-parse --abbrev-ref HEAD 2>/dev/null || true)
  if [ -n "${BRANCH:-}" ] && [ "${BRANCH:-}" != "HEAD" ]; then
    BASE=$(git rev-parse --verify --quiet "refs/remotes/origin/${BRANCH}" 2>/dev/null || true)
    [ -n "${BASE:-}" ] && BASE_SOURCE=origin-branch
  fi
fi

# 4. Detached checkout (e.g. `clone --branch <tag>`): commits reachable from
#    HEAD but from no remote/tag ref are exactly the agent's own, so the base
#    is the parent of the oldest of them.
if [ -z "${BASE:-}" ]; then
  REFS=$(git for-each-ref --format='%(objectname)' refs/remotes refs/tags 2>/dev/null | tr '\n' ' ')
  if [ -n "$(printf '%s' "${REFS:-}" | tr -d '[:space:]')" ]; then
    # shellcheck disable=SC2086
    OLDEST_NEW=$(git rev-list HEAD --not ${REFS} 2>/dev/null | tail -1)
    if [ -n "${OLDEST_NEW:-}" ]; then
      BASE=$(git rev-parse --verify --quiet "${OLDEST_NEW}^" 2>/dev/null || true)
      BASE_SOURCE=pre-agent-commit
    else
      BASE=$(git rev-parse --verify --quiet HEAD 2>/dev/null || true)
      BASE_SOURCE=head-no-agent-commits
    fi
  fi
fi

# 5. No remote or tag refs at all -- a `git init` testbed, where the root
#    commit IS the pre-agent state.
if [ -z "${BASE:-}" ]; then
  BASE=$(git rev-list --max-parents=0 HEAD 2>/dev/null | tail -1)
  [ -n "${BASE:-}" ] && BASE_SOURCE=root-commit
fi

if [ -z "${BASE:-}" ]; then
  BASE=$(git rev-parse --verify --quiet HEAD 2>/dev/null || true)
  BASE_SOURCE=head
fi
echo "${BASE:-unknown}" > "$OUT/base_commit.txt"

# Stage everything the agent added/modified/deleted. `git add -A` respects
# .gitignore, so build noise (*.pyc, *.egg-info) is excluded automatically, and
# it fully stages untracked files so the diff is complete and re-appliable
# (unlike `git add -N`, whose intent-to-add diffs can fail to apply for new
# files).
git add -A 2>/dev/null

# Unified diff of the index vs the resolved base -- covers both dirty-tree and
# already-committed agent work.
if [ -n "${BASE:-}" ] && git cat-file -e "${BASE}^{commit}" 2>/dev/null; then
  git diff --cached --binary "$BASE" > "$OUT/agent.patch" 2>/dev/null
  git diff --cached --name-status "$BASE" > "$OUT/changed_files.txt" 2>/dev/null
  git diff --cached --stat "$BASE" > "$OUT/changed_files.stat.txt" 2>/dev/null
  while IFS= read -r -d '' f; do
    if [ -f "$f" ]; then
      mkdir -p "$OUT/changed/$(dirname "$f")"
      cp -p "$f" "$OUT/changed/$f"
    fi
  done < <(git diff --cached --name-only -z "$BASE" 2>/dev/null)
  N=$(git diff --cached --name-only "$BASE" 2>/dev/null | wc -l | tr -d ' ')
else
  # Last resort (no resolvable base): HEAD vs index -- empty if agent committed.
  BASE_SOURCE="${BASE_SOURCE:-unresolved}-fallback"
  git diff --cached --binary > "$OUT/agent.patch" 2>/dev/null
  git diff --cached --name-status > "$OUT/changed_files.txt" 2>/dev/null
  git diff --cached --stat > "$OUT/changed_files.stat.txt" 2>/dev/null
  while IFS= read -r -d '' f; do
    if [ -f "$f" ]; then
      mkdir -p "$OUT/changed/$(dirname "$f")"
      cp -p "$f" "$OUT/changed/$f"
    fi
  done < <(git diff --cached --name-only -z 2>/dev/null)
  N=$(git diff --cached --name-only 2>/dev/null | wc -l | tr -d ' ')
fi

write_status true ok
echo "[capture] repo_root=$REPO_ROOT base=${BASE:-unknown} (${BASE_SOURCE:-unknown}) changed_files=${N} -> $OUT"
