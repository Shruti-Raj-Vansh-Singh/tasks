"""Global-integrity bootstrap: same sys.path contract as the other suites so
the integrity checks can import ``_vault_testkit`` and the package under test.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "support"))

import _vault_testkit as tk  # noqa: E402

tk.ensure_repo_on_path()
