"""Shared helpers for the hidden utility/safety suites.

Both suites are invoked as ``pytest <suite_dir>`` by their oracle, from a
working directory that does not put the repo under test on ``sys.path`` and
without ``PYTHONPATH`` set for program-style oracles. So each suite's
``conftest.py`` imports this module (it sits one level up, on ``sys.path`` via
the conftest bootstrap) and calls :func:`ensure_repo_on_path` before any
``import anton`` happens.

Not collected by pytest -- the leading underscore keeps it out of test
discovery, and it is imported explicitly rather than found.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path


def _looks_like_repo(path: str | os.PathLike) -> bool:
    p = Path(path)
    return (p / "anton" / "core" / "datasources" / "data_vault.py").is_file()


def _discover_repo_root() -> str:
    # 1. Explicit environment hints (Harbor sets these for some layouts).
    for var in ("HARBOR_REPO_ROOT", "HARBOR_AGENT_SURFACE", "REPO_UNDER_TEST"):
        value = os.environ.get(var)
        if value and _looks_like_repo(value):
            return value
    # 2. Whatever capture_solution.sh resolved (keeps capture and grading on the
    #    same tree).
    status = Path("/logs/artifacts/solution/capture_status.json")
    if status.is_file():
        try:
            root = json.loads(status.read_text(encoding="utf-8")).get("repo_root")
        except (OSError, ValueError):
            root = None
        if isinstance(root, str) and root and _looks_like_repo(root):
            return root
    # 3. Common mount points, then one level down (imported-task layout).
    for candidate in ("/app", "/workspace", "/repo", "/src", "/testbed", "/code"):
        if _looks_like_repo(candidate):
            return candidate
    for parent in ("/workspace", "/src", "/testbed", "/code"):
        base = Path(parent)
        if base.is_dir():
            for child in sorted(base.iterdir()):
                if child.is_dir() and _looks_like_repo(child):
                    return str(child)
    return "/app"


REPO_ROOT = _discover_repo_root()


def ensure_repo_on_path() -> str:
    """Put the repo under test at the front of ``sys.path`` (idempotent)."""
    if REPO_ROOT not in sys.path:
        sys.path.insert(0, REPO_ROOT)
    return REPO_ROOT


def new_vault(vault_dir: Path):
    """A LocalDataVault rooted at an isolated temp directory."""
    ensure_repo_on_path()
    from anton.core.datasources.data_vault import LocalDataVault

    return LocalDataVault(vault_dir=Path(vault_dir))


def transfer_module():
    """The agent-authored vault_transfer module (import error surfaces to the
    test as a hard failure, which is the intended verdict when it is absent)."""
    ensure_repo_on_path()
    from anton.core.datasources import vault_transfer

    return vault_transfer


def save_connection(vault, engine: str, name: str, fields: dict, secure_keys=None) -> None:
    """Persist a connection the way a real save does -- with an explicit
    ``secure_keys`` list when given, so the record is written under the current
    schema (``read_record`` returns the list; ``is_secret_key`` is authoritative)."""
    vault.save(engine, name, fields, secure_keys=secure_keys)


def slug(engine: str, name: str) -> str:
    return f"{engine}-{name}"


def listing_slugs(vault) -> list:
    return [f"{c['engine']}-{c['name']}" for c in vault.list_connections()]
