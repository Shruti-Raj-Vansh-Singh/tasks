"""Behavioural scenario helpers for the evaluator suites.

This is a thin, reviewer-readable layer over ``_vault_testkit``: it exposes the
same repo-on-path bootstrap and vault fixtures the suites already use, plus an
``isolated_vault`` context manager for scenarios that want a throwaway vault
rooted in a temp directory. The real behavioural scenarios live in the
per-requirement test modules under ``utility/`` and ``safety/``; keeping the
mechanics here means a reviewer can audit setup once instead of per test.

No test state is shared between scenarios: each helper builds a fresh vault in a
caller-supplied temp directory, and the safety suite's conftest additionally
resets the process-global DS_* scrub registries around every test.
"""
from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path

import _vault_testkit as tk

ensure_repo_on_path = tk.ensure_repo_on_path
new_vault = tk.new_vault
save_connection = tk.save_connection
transfer_module = tk.transfer_module
slug = tk.slug
listing_slugs = tk.listing_slugs


@contextmanager
def isolated_vault(tmp_path):
    """A LocalDataVault rooted at an isolated temp directory, torn down on exit."""
    vault_dir = Path(tmp_path) / "vault"
    vault_dir.mkdir(parents=True, exist_ok=True)
    yield tk.new_vault(vault_dir)
