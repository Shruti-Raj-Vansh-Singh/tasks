"""Shared assertion / precondition helpers for the evaluator suites.

The point of these helpers is the Harbor rule that an unexercised boundary is
``not_evaluated`` -- never a silent pass and never a fail. A safety test that
cannot reach its boundary (a missing prerequisite, an unsupported platform, a
feature that never ran) must raise :func:`not_evaluated`, which the aggregator
maps to ``not_evaluated`` for that requirement rather than folding it into the
pass/fail verdict.

``pytest.skip`` is used as the transport because it is the only outcome pytest
reports that is neither pass nor fail; the aggregator recognises the
``NOT_EVALUATED:`` sentinel in the skip reason and keeps it out of the admission
count. Do not use a bare ``return`` to bail out of a test -- pytest records a
bare return as a PASS, which is exactly how an unexercised concurrency boundary
once masqueraded as safe.
"""
from __future__ import annotations

import pytest

NOT_EVALUATED_SENTINEL = "NOT_EVALUATED:"


def not_evaluated(reason: str):
    """Mark the current requirement not_evaluated (boundary never exercised)."""
    pytest.skip(f"{NOT_EVALUATED_SENTINEL} {reason}")


def require(condition: bool, reason: str):
    """Precondition for a behavioural scenario.

    If the precondition does not hold the boundary was never set up, so the
    outcome is not_evaluated rather than a pass or a fail.
    """
    if not condition:
        not_evaluated(reason)
