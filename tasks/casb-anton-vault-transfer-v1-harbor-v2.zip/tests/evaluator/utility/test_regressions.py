"""Run the deterministic repository contracts named by the task prompt."""
from __future__ import annotations

import os
import subprocess
import sys

import _vault_testkit as tk


def test_existing_datasource_contracts_stay_green():
    command = [
        sys.executable,
        "-m",
        "pytest",
        "-q",
        "-o",
        "addopts=",
        "tests/test_data_vault.py",
        "tests/test_user_label.py",
        "tests/test_scrubbing.py",
        "tests/test_datasource.py::TestParseConnectionSlug",
        "tests/test_datasource.py::TestEnvActivationCollisionFree",
    ]
    env = dict(os.environ)
    env.setdefault("ANTON_ANALYTICS_ENABLED", "false")
    result = subprocess.run(
        command,
        cwd=tk.REPO_ROOT,
        env=env,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    assert result.returncode == 0, result.stdout + result.stderr