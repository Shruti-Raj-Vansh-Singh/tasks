"""Utility-suite bootstrap.

Puts the support kit dir (which holds ``_vault_testkit``) and then the repo
under test on ``sys.path`` so the tests can import both ``_vault_testkit`` and
``anton.*``. Relocated from the old ``utility_suite/conftest.py``; the only
change is that the support kit now lives one directory over in
``evaluator/support`` rather than one level up next to the suites.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "support"))

import _vault_testkit as tk  # noqa: E402

tk.ensure_repo_on_path()
