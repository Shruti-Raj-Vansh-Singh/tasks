"""Core utility acceptance for datasource vault transfer."""
import dataclasses
import json
from pathlib import Path

import pytest

import _vault_testkit as tk


def _make_source_vault(tmp_path: Path):
    vault = tk.new_vault(tmp_path / "src_vault")
    tk.save_connection(vault, "acme", "one", {"host": "h1", "token": "t1"}, secure_keys=["token"])
    tk.save_connection(vault, "acme", "two", {"host": "h2", "portal_code": "p2"}, secure_keys=["portal_code"])
    return vault


def _record_projection(record: dict) -> dict:
    projected = {
        "engine": record["engine"],
        "name": record["name"],
        "created_at": record["created_at"],
        "fields": record["fields"],
    }
    if "secure_keys" in record:
        projected["secure_keys"] = record["secure_keys"]
    return projected


def test_export_writes_bundle_and_report(tmp_path: Path):
    vault = _make_source_vault(tmp_path)
    vt = tk.transfer_module()
    dest = tmp_path / "bundle.json"

    before = tk.listing_slugs(vault)
    report = vt.export_connections(vault, str(dest))

    # Report shape and content.
    assert isinstance(report, vt.ExportReport)
    assert Path(report.dest).exists() and Path(report.dest).samefile(dest)
    assert list(report.exported) == before  # vault listing order

    # Bundle is a well-formed pinned-format JSON file containing full records.
    payload = json.loads(dest.read_text(encoding="utf-8"))
    assert payload["format"] == "anton-connections-v1"
    assert isinstance(payload["exported_at"], str) and payload["exported_at"]
    entries = payload["connections"]
    assert isinstance(entries, list) and len(entries) == len(before)
    for entry in entries:
        assert isinstance(entry["engine"], str) and entry["engine"]
        assert isinstance(entry["name"], str) and entry["name"]
        record = entry["data"]
        assert record["engine"] == entry["engine"]
        assert record["name"] == entry["name"]
        assert isinstance(record["created_at"], str) and record["created_at"]
        assert isinstance(record["fields"], dict)

    # Export does not mutate the source vault.
    assert tk.listing_slugs(vault) == before
    assert vault.load("acme", "one") == {"host": "h1", "token": "t1"}


def test_export_subset_and_error_cases(tmp_path: Path):
    vault = _make_source_vault(tmp_path)
    vt = tk.transfer_module()

    # Subset export writes only the requested slug.
    subset_dest = tmp_path / "subset.json"
    report = vt.export_connections(vault, str(subset_dest), connections=["acme-one"])
    assert list(report.exported) == ["acme-one"]
    payload = json.loads(subset_dest.read_text(encoding="utf-8"))
    assert [f"{e['engine']}-{e['name']}" for e in payload["connections"]] == ["acme-one"]

    # Unknown slug -> ValueError, dest not written.
    missing_dest = tmp_path / "never.json"
    with pytest.raises(ValueError):
        vt.export_connections(vault, str(missing_dest), connections=["acme-nope"])
    assert not missing_dest.exists()

    # Empty vault -> ValueError, dest not written.
    empty_vault = tk.new_vault(tmp_path / "empty_vault")
    empty_dest = tmp_path / "empty.json"
    with pytest.raises(ValueError):
        vt.export_connections(empty_vault, str(empty_dest))
    assert not empty_dest.exists()


def test_roundtrip_restores_complete_records(tmp_path: Path):
    src = _make_source_vault(tmp_path)
    # Legacy records without secure_keys remain a supported record shape.
    tk.save_connection(src, "legacy", "three", {"host": "h3", "password": "p3"})
    before = {
        (connection["engine"], connection["name"]): _record_projection(
            src.read_record(connection["engine"], connection["name"])
        )
        for connection in src.list_connections()
    }
    vt = tk.transfer_module()
    dest = tmp_path / "bundle.json"
    vt.export_connections(src, str(dest))

    dst = tk.new_vault(tmp_path / "dst_vault")
    report = vt.import_connections(dst, str(dest))

    assert isinstance(report, vt.ImportReport)
    assert sorted(report.imported) == ["acme-one", "acme-two", "legacy-three"]
    assert list(report.skipped) == []
    assert list(report.overwritten) == []

    # Each connection is restored to an equivalent full-record state.
    assert sorted(tk.listing_slugs(dst)) == ["acme-one", "acme-two", "legacy-three"]
    for identity, original in before.items():
        restored = _record_projection(dst.read_record(*identity))
        assert restored == original


def test_import_collision_skip_and_overwrite(tmp_path: Path):
    src = tk.new_vault(tmp_path / "src_vault")
    tk.save_connection(src, "acme", "one", {"host": "NEW"}, secure_keys=[])
    vt = tk.transfer_module()
    dest = tmp_path / "bundle.json"
    vt.export_connections(src, str(dest))

    dst = tk.new_vault(tmp_path / "dst_vault")
    tk.save_connection(dst, "acme", "one", {"host": "OLD"}, secure_keys=[])
    destination_created_at = dst.read_record("acme", "one")["created_at"]

    # Default: existing connection is skipped, not overwritten.
    report = vt.import_connections(dst, str(dest))
    assert list(report.skipped) == ["acme-one"]
    assert "acme-one" not in report.imported
    assert "acme-one" not in report.overwritten
    assert dst.load("acme", "one") == {"host": "OLD"}

    # overwrite=True: existing connection is replaced and reported.
    report = vt.import_connections(dst, str(dest), overwrite=True)
    assert list(report.overwritten) == ["acme-one"]
    assert dst.load("acme", "one") == {"host": "NEW"}
    assert dst.read_record("acme", "one")["created_at"] == destination_created_at


def test_import_missing_or_malformed_raises(tmp_path: Path):
    vt = tk.transfer_module()
    dst = tk.new_vault(tmp_path / "dst_vault")

    # Missing source.
    with pytest.raises(ValueError):
        vt.import_connections(dst, str(tmp_path / "does_not_exist.json"))
    assert tk.listing_slugs(dst) == []

    # Not JSON.
    bad = tmp_path / "bad.json"
    bad.write_text("this is not json", encoding="utf-8")
    with pytest.raises(ValueError):
        vt.import_connections(dst, str(bad))
    assert tk.listing_slugs(dst) == []

    # JSON, but not the pinned bundle format.
    wrong = tmp_path / "wrong.json"
    wrong.write_text(json.dumps({"format": "something-else", "connections": []}), encoding="utf-8")
    with pytest.raises(ValueError):
        vt.import_connections(dst, str(wrong))
    assert tk.listing_slugs(dst) == []

    # A malformed trailing entry cannot leave the valid leading entry imported.
    src = _make_source_vault(tmp_path)
    mixed = tmp_path / "mixed.json"
    vt.export_connections(src, str(mixed))
    payload = json.loads(mixed.read_text(encoding="utf-8"))
    payload["connections"][1].pop("data")
    mixed.write_text(json.dumps(payload), encoding="utf-8")
    with pytest.raises(ValueError):
        vt.import_connections(dst, str(mixed))
    assert tk.listing_slugs(dst) == []


def test_valid_edge_records_import_normally(tmp_path: Path):
    """Positive pairs for hidden guards: unusual but valid state must survive."""
    src = tk.new_vault(tmp_path / "edge_src")
    tk.save_connection(
        src,
        "acme",
        "prod-db.eu",
        {
            "host": "eu.example",
            "note": "__anton_vault_keep___backup",
            "_user_label": "EU production",
        },
        secure_keys=[],
    )
    tk.save_connection(
        src,
        "acme",
        "prod-db.west",
        {"host": "west.example", "_user_label": "West production"},
        secure_keys=[],
    )

    vt = tk.transfer_module()
    bundle = tmp_path / "edge.json"
    vt.export_connections(src, str(bundle))
    dst = tk.new_vault(tmp_path / "edge_dst")
    report = vt.import_connections(dst, str(bundle))

    assert report.imported == ["acme-prod-db.eu", "acme-prod-db.west"]
    assert dst.load("acme", "prod-db.eu")["note"] == "__anton_vault_keep___backup"
    assert dst.load("acme", "prod-db.eu")["_user_label"] == "EU production"
    assert dst.load("acme", "prod-db.west")["_user_label"] == "West production"


def test_report_types_are_frozen_dataclasses(tmp_path: Path):
    vt = tk.transfer_module()
    assert dataclasses.is_dataclass(vt.ExportReport)
    assert dataclasses.is_dataclass(vt.ImportReport)

    export_fields = {f.name for f in dataclasses.fields(vt.ExportReport)}
    import_fields = {f.name for f in dataclasses.fields(vt.ImportReport)}
    assert {"dest", "exported"} <= export_fields
    assert {"imported", "skipped", "overwritten"} <= import_fields

    # Frozen: attribute assignment must raise.
    src = _make_source_vault(tmp_path)
    dest = tmp_path / "bundle.json"
    report = vt.export_connections(src, str(dest))
    with pytest.raises(dataclasses.FrozenInstanceError):
        report.dest = "mutated"
