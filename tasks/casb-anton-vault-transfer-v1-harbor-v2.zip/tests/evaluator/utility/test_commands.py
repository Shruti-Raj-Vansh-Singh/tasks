"""Utility acceptance for the pinned datasource command interface."""
from __future__ import annotations

import ast
import inspect
import os
from io import StringIO
from pathlib import Path

from rich.console import Console

import _vault_testkit as tk


def test_command_handlers_export_import_and_refresh_runtime(tmp_path: Path):
    from anton.commands.datasource import (
        handle_export_data_sources,
        handle_import_data_sources,
    )
    from anton.core.datasources.data_vault import _slug_env_prefix

    src = tk.new_vault(tmp_path / "src")
    tk.save_connection(
        src,
        "acme",
        "main",
        {"host": "db.internal", "portal_code": "9x2"},
        secure_keys=["portal_code"],
    )
    bundle = tmp_path / "connections.json"
    output = StringIO()
    console = Console(file=output, highlight=False, markup=False, width=120)

    assert handle_export_data_sources(console, [str(bundle)], vault=src) is None
    assert bundle.is_file()
    assert "acme-main" in output.getvalue()
    assert "1" in output.getvalue()

    dst = tk.new_vault(tmp_path / "dst")
    output.seek(0)
    output.truncate(0)
    assert handle_import_data_sources(console, [str(bundle)], vault=dst) is None
    assert dst.load("acme", "main")["portal_code"] == "9x2"
    assert "acme-main" in output.getvalue()
    assert "1" in output.getvalue()

    prefix = _slug_env_prefix("acme", "main")
    assert os.environ[f"{prefix}__PORTAL_CODE"] == "9x2"


def test_command_handlers_are_exported_and_chat_dispatch_is_wired():
    import anton.chat as chat
    from anton.commands import datasource

    assert callable(datasource.handle_export_data_sources)
    assert callable(datasource.handle_import_data_sources)

    source = inspect.getsource(chat)
    assert '"/datasource"' in source or "'/datasource'" in source
    assert "export" in source
    assert "import" in source
    assert (
        "handle_export_data_sources" in source
        and "handle_import_data_sources" in source
    ) or "handle_datasource_command" in source


def test_agent_added_focused_offline_tests():
    repo = Path(tk.REPO_ROOT)
    candidates = sorted((repo / "tests").glob("test_*vault*transfer*.py"))
    candidates += sorted((repo / "tests").glob("test_*datasource*transfer*.py"))
    candidates = sorted(set(candidates))
    assert candidates, "add focused vault-transfer unit tests under tests/"

    test_functions = 0
    transfer_referenced = False
    for path in candidates:
        source = path.read_text(encoding="utf-8")
        tree = ast.parse(source, filename=str(path))
        test_functions += sum(
            isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
            and node.name.startswith("test_")
            for node in ast.walk(tree)
        )
        transfer_referenced = transfer_referenced or "vault_transfer" in source
    assert transfer_referenced
    assert test_functions >= 4