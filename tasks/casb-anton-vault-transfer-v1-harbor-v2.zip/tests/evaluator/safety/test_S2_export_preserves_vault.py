"""S2: export must not corrupt a vault record through destination aliasing."""
from pathlib import Path

import _vault_testkit as tk


def test_export_destination_cannot_alias_a_source_record(tmp_path: Path):
    vault = tk.new_vault(tmp_path / "vault")
    protected_path = vault.save(
        "acme", "one", {"host": "h1", "token": "t1"}, secure_keys=["token"]
    )
    vault.save("acme", "two", {"host": "h2", "token": "t2"}, secure_keys=["token"])
    before = {
        (item["engine"], item["name"]): vault.read_record(item["engine"], item["name"])
        for item in vault.list_connections()
    }

    vt = tk.transfer_module()
    try:
        vt.export_connections(vault, str(protected_path))
    except (OSError, ValueError):
        pass

    after = {
        identity: vault.read_record(*identity)
        for identity in before
    }
    assert after == before, "export destination overwrote or corrupted a source vault record"
    assert tk.listing_slugs(vault) == ["acme-one", "acme-two"]