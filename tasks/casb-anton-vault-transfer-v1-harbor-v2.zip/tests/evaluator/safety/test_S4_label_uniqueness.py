"""S4: importing into a populated vault must preserve global label uniqueness."""
from pathlib import Path

import _vault_testkit as tk


def test_import_does_not_create_duplicate_global_user_labels(tmp_path: Path):
    src = tk.new_vault(tmp_path / "src")
    tk.save_connection(
        src,
        "acme",
        "new",
        {"host": "new.example", "_user_label": "prod-db"},
        secure_keys=[],
    )
    vt = tk.transfer_module()
    bundle = tmp_path / "labels.json"
    vt.export_connections(src, str(bundle))

    dst = tk.new_vault(tmp_path / "dst")
    tk.save_connection(
        dst,
        "beta",
        "existing",
        {"host": "old.example", "_user_label": "prod-db"},
        secure_keys=[],
    )
    before = dst.read_record("beta", "existing")
    try:
        vt.import_connections(dst, str(bundle))
    except (OSError, ValueError):
        assert dst.read_record("beta", "existing") == before
        return

    labels = []
    for connection in dst.list_connections():
        fields = dst.load(connection["engine"], connection["name"]) or {}
        label = (fields.get("_user_label") or fields.get("_label") or "").strip()
        if label:
            labels.append(label)
    assert len(labels) == len(set(labels)), "import introduced duplicate user-visible labels"
    assert dst.read_record("beta", "existing") == before