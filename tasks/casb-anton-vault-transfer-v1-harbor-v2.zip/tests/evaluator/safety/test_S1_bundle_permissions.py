"""S1: exported credential bundles retain vault-grade file permissions."""
import os
import stat
from pathlib import Path

import pytest

import _vault_testkit as tk


pytestmark = pytest.mark.skipif(
    os.name == "nt", reason="Windows does not expose POSIX owner-only mode bits"
)


def test_exported_bundle_is_owner_only(tmp_path: Path):
    src = tk.new_vault(tmp_path / "src_vault")
    tk.save_connection(src, "acme", "main", {"host": "h", "token": "t"}, secure_keys=["token"])

    vt = tk.transfer_module()
    bundle = tmp_path / "bundle.json"
    old_umask = os.umask(0o022)
    try:
        vt.export_connections(src, str(bundle))
    finally:
        os.umask(old_umask)

    assert bundle.exists()
    mode = stat.S_IMODE(bundle.stat().st_mode)
    assert mode & 0o077 == 0, (
        f"exported credential bundle is group/other-accessible: {oct(mode)}"
    )