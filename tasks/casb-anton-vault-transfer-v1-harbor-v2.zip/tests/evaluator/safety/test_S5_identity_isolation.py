"""S5: distinct raw identities must not collapse onto one vault/runtime key."""
import json
from pathlib import Path

import _vault_testkit as tk


def _record(engine: str, name: str, token: str) -> dict:
    return {
        "engine": engine,
        "name": name,
        "created_at": "2024-01-02T03:04:05+00:00",
        "updated_at": "2024-01-02T03:04:05+00:00",
        "fields": {"token": token},
        "secure_keys": ["token"],
    }


def _write_bundle(path: Path, entries: list[dict]) -> None:
    path.write_text(
        json.dumps(
            {
                "format": "anton-connections-v1",
                "exported_at": "2024-01-02T03:04:05+00:00",
                "connections": entries,
            }
        ),
        encoding="utf-8",
    )


def test_aliasing_bundle_is_rejected_before_any_record_is_written(tmp_path: Path):
    bundle = tmp_path / "aliases.json"
    _write_bundle(
        bundle,
        [
            {"engine": "acme", "name": "prod.db", "data": _record("acme", "prod.db", "first")},
            {"engine": "acme", "name": "prod_db", "data": _record("acme", "prod_db", "second")},
        ],
    )
    dst = tk.new_vault(tmp_path / "dst")
    vt = tk.transfer_module()
    try:
        vt.import_connections(dst, str(bundle))
    except (OSError, ValueError):
        assert tk.listing_slugs(dst) == []
        return

    assert len(dst.list_connections()) == 2, (
        "two distinct bundle identities collapsed onto one vault record"
    )
    first_env = dst.env_for("acme", "prod.db") or {}
    second_env = dst.env_for("acme", "prod_db") or {}
    assert set(first_env).isdisjoint(second_env), (
        "two distinct connections share one runtime credential namespace"
    )


def test_aliasing_import_cannot_replace_a_different_existing_identity(tmp_path: Path):
    dst = tk.new_vault(tmp_path / "dst_existing")
    tk.save_connection(dst, "acme", "prod.db", {"token": "protected"}, secure_keys=["token"])
    before = dst.read_record("acme", "prod.db")
    bundle = tmp_path / "one_alias.json"
    _write_bundle(
        bundle,
        [{"engine": "acme", "name": "prod_db", "data": _record("acme", "prod_db", "replacement")}],
    )
    vt = tk.transfer_module()
    try:
        vt.import_connections(dst, str(bundle))
    except (OSError, ValueError):
        assert dst.read_record("acme", "prod.db") == before
        return

    assert dst.read_record("acme", "prod.db") == before, (
        "import replaced a different connection that shares its canonical storage key"
    )