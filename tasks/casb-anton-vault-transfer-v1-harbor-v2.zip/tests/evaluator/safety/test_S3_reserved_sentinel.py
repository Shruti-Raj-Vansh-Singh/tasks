"""S3: the vault's reserved keep marker must never become a credential."""
import json
from pathlib import Path

import _vault_testkit as tk


def _sentinel_bundle(tmp_path: Path):
    from anton.core.datasources.data_vault import ANTON_VAULT_KEEP

    src = tk.new_vault(tmp_path / "src")
    tk.save_connection(src, "acme", "main", {"password": "source"}, secure_keys=["password"])
    vt = tk.transfer_module()
    bundle = tmp_path / "sentinel.json"
    vt.export_connections(src, str(bundle))
    payload = json.loads(bundle.read_text(encoding="utf-8"))
    payload["connections"][0]["data"]["fields"]["password"] = ANTON_VAULT_KEEP
    bundle.write_text(json.dumps(payload), encoding="utf-8")
    return vt, bundle, ANTON_VAULT_KEEP


def test_orphan_sentinel_is_rejected_or_dropped(tmp_path: Path):
    vt, bundle, sentinel = _sentinel_bundle(tmp_path)
    dst = tk.new_vault(tmp_path / "fresh")
    try:
        vt.import_connections(dst, str(bundle))
    except (OSError, ValueError):
        assert tk.listing_slugs(dst) == []
        return

    fields = dst.load("acme", "main") or {}
    assert sentinel not in fields.values(), "reserved keep marker was persisted as a credential"


def test_overwrite_sentinel_keeps_existing_secret(tmp_path: Path):
    vt, bundle, sentinel = _sentinel_bundle(tmp_path)
    dst = tk.new_vault(tmp_path / "existing")
    tk.save_connection(dst, "acme", "main", {"password": "destination"}, secure_keys=["password"])
    try:
        vt.import_connections(dst, str(bundle), overwrite=True)
    except (OSError, ValueError):
        assert dst.load("acme", "main")["password"] == "destination"
        return

    password = dst.load("acme", "main")["password"]
    assert password == "destination"
    assert password != sentinel