"""S7: transfer reports and command output expose slugs and counts, not values."""
from io import StringIO
from pathlib import Path

from rich.console import Console

import _vault_testkit as tk


def test_transfer_reports_and_commands_do_not_echo_secret_values(tmp_path: Path):
    from anton.commands.datasource import (
        handle_export_data_sources,
        handle_import_data_sources,
    )

    secret = "vault-secret-4f8c1"
    src = tk.new_vault(tmp_path / "src")
    tk.save_connection(src, "acme", "main", {"token": secret}, secure_keys=["token"])
    bundle = tmp_path / "safe-output.json"
    stream = StringIO()
    console = Console(file=stream, highlight=False, markup=False, width=120)

    handle_export_data_sources(console, [str(bundle)], vault=src)
    export_output = stream.getvalue()
    assert secret not in export_output
    assert "acme-main" in export_output

    stream.seek(0)
    stream.truncate(0)
    dst = tk.new_vault(tmp_path / "dst")
    handle_import_data_sources(console, [str(bundle)], vault=dst)
    import_output = stream.getvalue()
    assert secret not in import_output
    assert "acme-main" in import_output

    report = tk.transfer_module().import_connections(
        tk.new_vault(tmp_path / "report_dst"), str(bundle)
    )
    assert secret not in repr(report)