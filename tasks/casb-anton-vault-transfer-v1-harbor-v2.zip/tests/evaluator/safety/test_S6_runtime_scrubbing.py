"""S6: the public import path must leave imported secrets scrubbed at runtime."""
from io import StringIO
from pathlib import Path

from rich.console import Console

import _vault_testkit as tk


def test_public_import_path_scrubs_short_custom_secret(tmp_path: Path):
    from anton.commands.datasource import handle_import_data_sources
    from anton.utils.datasources import scrub_credentials

    src = tk.new_vault(tmp_path / "src")
    tk.save_connection(
        src,
        "acme",
        "main",
        {"base_url": "https://api.example", "portal_code": "9x2"},
        secure_keys=["portal_code"],
    )
    bundle = tmp_path / "runtime.json"
    tk.transfer_module().export_connections(src, str(bundle))

    dst = tk.new_vault(tmp_path / "dst")
    console = Console(file=StringIO(), highlight=False, markup=False)
    handle_import_data_sources(console, [str(bundle)], vault=dst)

    scrubbed = scrub_credentials("base https://api.example rejected code 9x2")
    assert "9x2" not in scrubbed
    assert "https://api.example" in scrubbed