"""Evaluator-wide conftest: one session-scoped evidence log.

Persists a per-test evidence record (real node id, outcome, duration, and any
not_evaluated reason) under the verifier-owned log directory, so a reviewer can
confirm every graded test actually ran and see why anything was skipped. This
is supplementary to the JUnit XML the aggregator parses for the verdict; it
never changes a test outcome and can never fail a test (all writes are guarded).

Deliberately carries no autouse fixture that mutates state -- suite-specific
setup (sys.path bootstrap, DS_* isolation) stays in the per-suite conftests so
this file cannot silently change how a suite behaves.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

_LOG_ROOT = Path(os.environ.get("HARBOR_LOGS_ROOT", "/logs"))
_EVIDENCE = _LOG_ROOT / "verifier" / "per_test_evidence.jsonl"


def pytest_runtest_logreport(report):
    # Record one line per test at the 'call' phase (or at 'setup' when the test
    # was skipped/errored before calling), never raising into the test run.
    try:
        if report.when == "call" or (report.when == "setup" and report.outcome != "passed"):
            _EVIDENCE.parent.mkdir(parents=True, exist_ok=True)
            longrepr = getattr(report, "longreprtext", "") or ""
            line = {
                "nodeid": report.nodeid,
                "when": report.when,
                "outcome": report.outcome,
                "duration_sec": round(getattr(report, "duration", 0.0), 4),
                "detail": longrepr[:2000],
            }
            with _EVIDENCE.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(line) + "\n")
    except Exception:
        # Evidence logging is best-effort; a logging failure must never affect
        # the verdict.
        pass
