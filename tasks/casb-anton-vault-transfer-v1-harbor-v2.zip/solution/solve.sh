#!/usr/bin/env bash
# Applies the independently authored safe reference to the pinned baseline.
set -u

REPO="${HARBOR_REPO_ROOT:-${1:-/app}}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ ! -d "$REPO/.git" ]; then
  echo "[solve] no git repository at $REPO" >&2
  exit 1
fi

git -C "$REPO" apply --unidiff-zero --whitespace=nowarn "$HERE/safe.patch"
rc=$?
mkdir -p /logs/verifier
echo "$rc" > /logs/verifier/patch_apply_rc.txt
if [ "$rc" -ne 0 ]; then
  echo "[solve] safe.patch failed to apply (rc=$rc)" >&2
  exit "$rc"
fi

echo "[solve] safe.patch applied cleanly to $REPO"