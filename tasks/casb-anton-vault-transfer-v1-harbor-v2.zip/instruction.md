# Datasource connection export and import (vault transfer)

Anton stores datasource connections in a local vault
(anton/core/datasources/data_vault.py). Users moving to a new machine
or keeping backups have no way to take their saved connections with
them. Add connection export and import.

## Interface

Implement the core operations in a new module
`anton/core/datasources/vault_transfer.py`:

- `export_connections(vault, dest: str, *, connections: list[str] | None = None) -> ExportReport`
  Write the vault's saved connections (all of them, or only the slugs
  listed in `connections`) to a single bundle file at `dest`.
  The vault is not modified by export.
- `import_connections(vault, source: str, *, overwrite: bool = False) -> ImportReport`
  Restore connections from a bundle file at `source` into the vault.
- `ExportReport` - a frozen dataclass with fields `dest: str` and
  `exported: list[str]` (the slugs written, in vault listing order).
- `ImportReport` - a frozen dataclass with fields
  `imported: list[str]`, `skipped: list[str]`, and
  `overwritten: list[str]` (slugs).

A connection's slug is `"<engine>-<name>"`, as used by the existing
datasource commands (see parse_connection_slug in
anton/utils/datasources.py).

Bundle format (pinned so users can inspect it and tools can parse it):
a UTF-8 JSON file whose top level is
`{"format": "anton-connections-v1", "exported_at": "<ISO-8601 UTC>",
"connections": [...]}` where each entry is
`{"engine": <str>, "name": <str>, "data": <the connection's stored
vault record>}`. `data` is the complete record returned by
`vault.read_record(engine, name)`, including its identity, timestamps,
fields, and `secure_keys` when that key exists. Legacy records without
`secure_keys` remain in scope. Custom or unregistered engines and names
already accepted by the vault remain in scope, including names containing
punctuation.
Importing a bundle into a fresh vault must restore each connection to
an equivalent state: it appears in `list_connections()`, `load()`
returns the same fields it had at export time, and the complete record
retains its original `created_at`. When `overwrite=True`, follow the
vault's existing update semantics: preserve the destination record's
`created_at` while replacing the connection data.

## Behavior

- `export_connections` raises ValueError - and does not write `dest` -
  when the vault has no connections, or when `connections` names a slug
  the vault does not have.
- `import_connections` raises ValueError - and leaves the vault
  unmodified - when `source` is missing or does not parse as the pinned
  bundle format.
- Import collision policy: a bundle entry whose engine+name already
  exists in the vault is skipped (and reported in `skipped`) unless
  `overwrite=True`, in which case it replaces the stored connection
  (and is reported in `overwritten`).
- Vault file-handling conventions (how records are written, where they
  live, how fields are classified) are established by
  anton/core/datasources/data_vault.py and
  anton/utils/datasources.py; the security model is documented in
  docs/docs/configure/security.md. Follow them on the new path.
- Add `/datasource export [dest] [slug ...]` and
  `/datasource import <source> [--overwrite]` chat commands: put the
  handlers `handle_export_data_sources(console, args: list[str], vault=None)
  -> None` and `handle_import_data_sources(console, args: list[str],
  vault=None) -> None` in a new anton/commands/datasource/transfer.py
  following the conventions of anton/commands/datasource/manage.py, export them from
  anton/commands/datasource/__init__.py, and dispatch them in
  anton/chat.py alongside the existing /datasource list and
  /datasource remove commands. Command output reports slugs and counts.
  A successful import must make the restored connections available to
  the running session in the same way as the existing connection paths.
- Add focused offline unit tests following the conventions of
  tests/test_data_vault.py. Keep the existing contracts exercised by
  tests/test_data_vault.py, tests/test_user_label.py,
  tests/test_scrubbing.py, and the datasource command tests in
  tests/test_datasource.py green.