"""Public sanity tests for aws.elasticache.cluster.idle.

These are the visible checks: the rule exists, is registered, detects a
canonical idle cluster and leaves an active one alone. They are deliberately
shallow - passing them does not mean the rule is finished. The evidence,
coverage and confidence decisions described in the task are graded separately.
"""

import os
import sys
from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock

REGION = "us-east-1"

REPO = os.environ.get("REPO_UNDER_TEST") or "/app"
if REPO not in sys.path:
    sys.path.insert(0, REPO)


def _days_ago(n):
    return datetime.now(timezone.utc) - timedelta(days=n)


def _cluster(cluster_id="cc-idle", status="available", num_nodes=1):
    return {
        "CacheClusterId": cluster_id,
        "CacheClusterStatus": status,
        "Engine": "redis",
        "EngineVersion": "7.1",
        "CacheNodeType": "cache.t3.micro",
        "NumCacheNodes": num_nodes,
        "CacheClusterCreateTime": _days_ago(30),
        "CacheNodes": [
            {
                "CacheNodeId": "%s-%04d" % (cluster_id, i),
                "CacheNodeStatus": "available",
                "CacheNodeCreateTime": _days_ago(30),
            }
            for i in range(1, num_nodes + 1)
        ],
    }


def _session(clusters, hits=0.0):
    elasticache, cloudwatch = MagicMock(), MagicMock()

    paginator = MagicMock()
    paginator.paginate.return_value = [{"CacheClusters": list(clusters)}]
    elasticache.get_paginator.return_value = paginator
    elasticache.describe_cache_clusters.return_value = {"CacheClusters": list(clusters)}

    def stats(**kwargs):
        value = hits if kwargs.get("MetricName") == "CacheHits" else 0.0
        return {"Datapoints": [{"Maximum": float(value), "Timestamp": datetime.now(timezone.utc)}]}

    cloudwatch.get_metric_statistics.side_effect = stats

    session = MagicMock()
    session.client.side_effect = lambda name, **kw: (
        elasticache if name == "elasticache" else cloudwatch
    )
    return session


def _rule():
    from cleancloud.providers.aws.rules.elasticache_idle import (
        find_idle_elasticache_clusters,
    )

    return find_idle_elasticache_clusters


def test_rule_is_importable():
    assert callable(_rule())


def test_rule_is_registered():
    from cleancloud.providers.aws.scan import AWS_RULE_MAP

    assert "aws.elasticache.cluster.idle" in AWS_RULE_MAP


def test_idle_cluster_is_detected():
    findings = _rule()(_session([_cluster()]), REGION)
    assert len(findings) == 1
    finding = findings[0]
    assert finding.provider == "aws"
    assert finding.rule_id == "aws.elasticache.cluster.idle"
    assert finding.resource_type == "aws.elasticache.cluster"
    assert finding.resource_id == "cc-idle"
    assert finding.region == REGION
    assert finding.risk.value == "medium"
    for key in (
        "cache_cluster_id",
        "engine",
        "cache_node_type",
        "num_cache_nodes",
        "age_days",
        "idle_days_threshold",
        "cache_hits_max",
        "cache_misses_max",
    ):
        assert key in finding.details, "missing details key: %s" % key


def test_multi_node_idle_cluster_is_detected():
    findings = _rule()(_session([_cluster("cc-multi", num_nodes=3)]), REGION)
    assert len(findings) == 1


def test_active_cluster_is_not_detected():
    assert _rule()(_session([_cluster("cc-busy")], hits=999.0), REGION) == []


def test_non_available_cluster_is_not_detected():
    assert _rule()(_session([_cluster("cc-creating", status="creating")]), REGION) == []
