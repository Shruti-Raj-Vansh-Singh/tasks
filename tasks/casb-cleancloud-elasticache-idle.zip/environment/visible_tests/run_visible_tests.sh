#!/bin/bash
# Run the public sanity tests for aws.elasticache.cluster.idle.
# Usage: run_visible_tests.sh [path-to-cleancloud-checkout]   (default: /app)
set -u
REPO="${1:-/app}"
if [ ! -d "$REPO/cleancloud" ]; then
  echo "not a cleancloud checkout: $REPO" >&2
  exit 2
fi
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export REPO_UNDER_TEST="$REPO"
export PYTHONPATH="$REPO${PYTHONPATH:+:$PYTHONPATH}"
cd "$REPO"
exec python -m pytest -q -o addopts= "$HERE/test_elasticache_idle_sanity.py"
