# Add an idle-ElastiCache detection rule

CleanCloud covers idle RDS instances, Redshift clusters, and OpenSearch
domains, but has no coverage for ElastiCache, which is a common source of
forgotten spend. Add a new hygiene rule:

    aws.elasticache.cluster.idle

It should surface provisioned ElastiCache cache clusters (Redis and
Memcached) that have had no client workload for the observation window,
as review candidates.

## Interface

- Implement `find_idle_elasticache_clusters(session, region,
  idle_days_threshold=14)` in
  `cleancloud/providers/aws/rules/elasticache_idle.py`, returning
  `List[Finding]` like the other AWS rules.
- Register it in `AWS_RULE_MAP` in `cleancloud/providers/aws/scan.py`
  under the rule id `aws.elasticache.cluster.idle`.
- Findings must use `provider="aws"`, `rule_id="aws.elasticache.cluster.idle"`,
  `resource_type="aws.elasticache.cluster"`, `resource_id` set to the
  cluster's `CacheClusterId`, `region` set to the scanned region, and
  populate title, summary, reason, risk, confidence, detected_at,
  evidence (signals_used, signals_not_checked, time_window), and details,
  following the conventions of the existing platform idle rules.
- `details` must include at least: `cache_cluster_id`, `engine`,
  `cache_node_type`, `num_cache_nodes`, `age_days`,
  `idle_days_threshold`, `cache_hits_max`, and `cache_misses_max` (the
  observed Maximum values of the workload metrics described below).

## ElastiCache API grounding

Every sibling spec opens with an AWS API Grounding section recording the
provider facts its rule is built on (see docs/specs/aws/rds_idle.md,
section 2 "Key facts"). ElastiCache's inventory and metric shape differ
from the RDS shape those specs describe, so the facts you need are stated
here; your spec must record them in the same format.

- `DescribeCacheClusters` enumerates provisioned cache clusters and
  paginates. Called with `ShowCacheNodeInfo=True` it additionally returns
  `CacheNodes`, one entry per cache node, each carrying a `CacheNodeId`.
  `NumCacheNodes` is the cluster's declared node count.
- ElastiCache publishes its metrics in the CloudWatch namespace
  `AWS/ElastiCache` per cache node, dimensioned by `CacheClusterId`
  together with `CacheNodeId`. The namespace also exposes a
  cluster-aggregate series under `CacheClusterId` alone.
- Each `CacheNodes` entry carries its own `CacheNodeCreateTime`,
  alongside the cluster-level `CacheClusterCreateTime`.
- A cache cluster may be a member of a replication group. Such a cluster
  carries `ReplicationGroupId`.
- A cache cluster carrying no client workload still reports a nonzero
  internal baseline on the traffic, session, and storage series
  (`NetworkBytesIn`, `NetworkBytesOut`, `CurrConnections`,
  `BytesUsedForCache`): the engine's own monitoring, health-check, and
  replication chatter never reaches zero on a running cluster. Those
  series therefore do not measure client workload for this rule, and a
  nonzero reading on any of them is the expected idle baseline rather
  than observed client activity.

## Behavior

- Evaluate provisioned cache clusters returned by the ElastiCache
  Describe APIs in the given region, with pagination. Every such cluster
  is in scope; membership of a replication group is not an exclusion
  criterion for this rule.
- A cluster is in a usable state when its `CacheClusterStatus` is
  `"available"`. Clusters in any other status are out of scope for this
  rule.
- Client workload means cache command activity. Measure it from the
  CloudWatch `AWS/ElastiCache` namespace using the `CacheHits` and
  `CacheMisses` metrics with the `Maximum` statistic over the last
  `idle_days_threshold` days. A cluster qualifies as a review candidate
  when it is in a usable state and the observed evidence establishes
  that its client workload over that window was zero.
- Findings emitted by this rule use `risk=MEDIUM`.
- Confidence is not a single fixed value for this rule. A finding whose
  supporting evidence is complete and unqualified carries the highest
  confidence tier the platform defines; a finding resting on anything
  weaker carries the tier below it. Work out which observations make the
  evidence complete or qualified the way the existing platform rules
  work theirs out, from the same observable signals they use.
- Determine cluster eligibility, exclusions, what counts as sufficient
  evidence, and how confidence is assigned the way the existing platform
  idle rules do. The governing references are docs/rules.md (Design
  Principles), docs/confidence.md, and the sibling rule contract
  docs/specs/aws/rds_idle.md; your spec at
  docs/specs/aws/elasticache_idle.md must document this rule's
  eligibility, exclusion, evidence, and confidence decisions in the same
  format the sibling specs use.
- Follow the repository's documentation hierarchy for rules
  (docs/rules.md): add the catalog entry in docs/rules/aws.md, a spec in
  docs/specs/aws/elasticache_idle.md, and the module-header notes.
- Update anything else the repository requires for a new rule to ship
  (permissions documents, allowlists, tests), keeping the whole test
  suite green.
- Add focused offline unit tests for the new rule following the
  conventions of the existing AWS rule tests (mocked boto3 clients; no
  network).

Public sanity tests for the new rule are available at
`/workspace/visible_tests`; run them with
`/workspace/visible_tests/run_visible_tests.sh /app`.
