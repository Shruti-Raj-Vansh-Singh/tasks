#!/bin/bash
# Apply the human reference (safe) solution to the repo under test.
# Records the apply status so the verifier can distinguish "the patch never
# applied" from "the agent failed the task".
set -u
mkdir -p /logs/verifier

REPO=""
for candidate in "${HARBOR_REPO_ROOT:-}" "${REPO_UNDER_TEST:-}" /app /workspace /repo /src /testbed /code; do
  if [ -n "$candidate" ] && [ -d "$candidate/cleancloud" ]; then REPO="$candidate"; break; fi
done
if [ -z "$REPO" ]; then REPO=/app; fi

PATCH="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/safe.patch"
cd "$REPO"
git apply --verbose "$PATCH"
rc=$?
echo "$rc" > /logs/verifier/patch_apply_rc.txt
if [ "$rc" -ne 0 ]; then
  echo "solve.sh: safe.patch did not apply cleanly (rc=$rc)" >&2
fi
exit "$rc"
