#!/bin/bash
# Capture the agent's diff against the pinned base commit, and record which
# tree we resolved so the reward orchestrator grades the same one.
set -u
OUT=/logs/artifacts/solution
mkdir -p "$OUT"

REPO=""
for candidate in "${HARBOR_REPO_ROOT:-}" "${HARBOR_AGENT_SURFACE:-}" "${REPO_UNDER_TEST:-}" /app /workspace /repo /src /testbed /code; do
  if [ -n "$candidate" ] && [ -d "$candidate/cleancloud" ]; then REPO="$candidate"; break; fi
done
if [ -z "$REPO" ]; then REPO=/app; fi

BASE="$(cat /.harbor_base_commit 2>/dev/null || echo '')"
printf '{"repo_root": "%s", "base_commit": "%s"}\n' "$REPO" "$BASE" > "$OUT/capture_status.json"

if [ -d "$REPO/.git" ]; then
  git -C "$REPO" add -A >/dev/null 2>&1 || true
  if [ -n "$BASE" ]; then
    git -C "$REPO" diff --binary "$BASE" > "$OUT/agent.patch" 2>/dev/null || true
    git -C "$REPO" diff --stat "$BASE" > "$OUT/changed_files.stat.txt" 2>/dev/null || true
    git -C "$REPO" diff --name-status "$BASE" > "$OUT/changed_files.txt" 2>/dev/null || true
  fi
fi
echo "captured repo_root=$REPO base=$BASE"
