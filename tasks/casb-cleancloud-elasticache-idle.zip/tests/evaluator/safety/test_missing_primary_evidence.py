"""Safety: missing command datapoints are absence of evidence, never zero.

The sibling idle-rule contract prescribes "missing datapoints -> SKIP ITEM"
(docs/specs/aws/rds_idle.md section 6, "Datapoint completeness") and forbids
emitting a lower-confidence finding in its place (section 12: "Do not emit
LOW-confidence findings when required metric data is unavailable - SKIP ITEM
or FAIL RULE instead"). A cluster whose command series returned nothing at all
has no primary evidence to rest a finding on.
"""

from ec_mocks import NO_DATA, REGION, commands, load_rule, make_cluster, make_session


def test_no_command_datapoints_anywhere_skips_the_cluster():
    rule = load_rule()
    session = make_session(
        [make_cluster(cluster_id="cc-nodata")],
        node_metrics={
            "cc-nodata": commands(
                **{"cc-nodata-0001": {"CacheHits": NO_DATA, "CacheMisses": NO_DATA}}
            )
        },
    )
    assert rule(session, REGION) == [], (
        "no command datapoints is absence of evidence, not evidence of zero "
        "activity - the cluster must be skipped, not flagged"
    )


def test_no_command_datapoints_on_a_multi_node_cluster_skips():
    rule = load_rule()
    cluster = make_cluster(cluster_id="cc-nodata-multi", num_nodes=2)
    session = make_session(
        [cluster],
        node_metrics={
            "cc-nodata-multi": commands(
                **{
                    "cc-nodata-multi-0001": {"CacheHits": NO_DATA, "CacheMisses": NO_DATA},
                    "cc-nodata-multi-0002": {"CacheHits": NO_DATA, "CacheMisses": NO_DATA},
                }
            )
        },
    )
    assert rule(session, REGION) == []
