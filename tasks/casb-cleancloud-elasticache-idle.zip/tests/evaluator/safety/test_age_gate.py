"""Safety: a cluster below the age threshold is out of scope, whatever it reads.

docs/confidence.md ("Age-Based and State-Based Confidence"): "Resources below
the threshold are not flagged." docs/specs/aws/rds_idle.md section 8 models the
same gate. A cluster that has not existed for the full observation window has
not been observed long enough to establish abandonment.
"""

from ec_mocks import REGION, days_ago, load_rule, make_cluster, make_node, make_session


def test_cluster_younger_than_threshold_not_flagged():
    rule = load_rule()
    young = make_cluster(
        cluster_id="cc-young",
        create_time=days_ago(5),
        nodes=[make_node("cc-young-0001", days_ago(5))],
    )
    assert rule(make_session([young]), REGION) == []


def test_cluster_just_inside_the_window_not_flagged():
    rule = load_rule()
    borderline = make_cluster(
        cluster_id="cc-border",
        create_time=days_ago(13),
        nodes=[make_node("cc-border-0001", days_ago(13))],
    )
    assert rule(make_session([borderline]), REGION) == []
