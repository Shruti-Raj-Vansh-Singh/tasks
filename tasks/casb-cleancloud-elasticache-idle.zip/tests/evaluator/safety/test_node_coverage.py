"""Safety: evidence must cover every declared cache node.

The repository's only per-sub-resource idle rule requires zero activity
"across all billable production variants" (docs/rules/aws.md, the
aws.sagemaker.endpoint.idle entry) and skips the item outright when the
sub-resource inventory comes back empty
(cleancloud/providers/aws/rules/ai/sagemaker_endpoint_idle.py, the
"if not normalized_variants / if not billable_variants" guards).

ElastiCache declares its node count up front via NumCacheNodes, so a shorter
or absent CacheNodes inventory is directly observable: a node the API never
described cannot be measured, and "no activity on every node" is therefore not
established. docs/rules.md ("Conservative by default - false negatives over
false positives") settles which way to fail.
"""

from ec_mocks import REGION, load_rule, make_cluster, make_node, make_session


def test_short_node_inventory_skips():
    rule = load_rule()
    # Declares three nodes; the API described one.
    cluster = make_cluster(
        cluster_id="cc-short",
        num_nodes=3,
        nodes=[make_node("cc-short-0001")],
    )
    assert rule(make_session([cluster]), REGION) == [], (
        "one described node cannot establish that all three are idle"
    )


def test_absent_node_inventory_skips():
    rule = load_rule()
    cluster = make_cluster(cluster_id="cc-nonodes", num_nodes=2, nodes=[])
    assert rule(make_session([cluster]), REGION) == []
