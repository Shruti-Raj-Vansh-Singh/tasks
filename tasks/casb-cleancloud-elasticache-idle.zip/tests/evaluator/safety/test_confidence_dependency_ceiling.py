"""Safety: an external dependency caps the tier, independently of telemetry.

A cluster can have perfect, complete, unqualified telemetry and still not
warrant the top tier, because it carries a dependency the rule never examined.
The repository states this separately from the datapoint-completeness rule, in
the load-balancer contract - docs/specs/aws/elb_idle.md section 7, "Backend
Registration Context Contract":

    "Backend registration is contextual only. Zero registered targets/instances
     increases confidence but does not independently qualify a load balancer as
     idle."

implemented as:

    confidence = HIGH if not has_registered_instances else MEDIUM
        cleancloud/providers/aws/rules/elb_idle.py

The absence of the dependency is what promotes the tier; its presence holds the
finding at the base tier without excluding it. A replication-group member is
that shape: it is still billed, still flagged, but its group is an unexamined
dependency.

Independent of the evidence-completeness axis: an implementation that copies
the sibling per-sub-resource rule's `all_had_datapoints` ladder and stops there
passes that one and fails this one. The cluster here has COMPLETE telemetry -
every node described, old enough, datapoints present and zero - so nothing
about evidence quality is in play.
"""

import pytest

from ec_mocks import REGION, load_rule, make_cluster, make_session


def _only(findings, resource_id):
    matches = [f for f in findings if f.resource_id == resource_id]
    if not matches:
        pytest.skip(
            "rule emitted no finding for %s; confidence tier is not gradeable "
            "(suppression is graded by the utility suite)" % resource_id
        )
    return matches[0]


def test_replication_group_membership_caps_confidence_below_top_tier():
    rule = load_rule()
    member = make_cluster(cluster_id="cc-member", replication_group_id="rg-1")
    finding = _only(rule(make_session([member]), REGION), "cc-member")
    assert finding.confidence.value != "high", (
        "a replication-group member carries an unexamined external dependency, "
        "which the sibling load-balancer rule treats as a confidence ceiling"
    )


def test_multi_node_group_member_with_complete_evidence_still_capped():
    """Complete telemetry does not lift the dependency ceiling."""
    rule = load_rule()
    member = make_cluster(cluster_id="cc-grp-multi", num_nodes=3, replication_group_id="rg-9")
    finding = _only(rule(make_session([member]), REGION), "cc-grp-multi")
    assert finding.confidence.value != "high"
