"""Safety: the age gate runs on the LATEST relevant timestamp, not just creation.

The repository's per-sub-resource idle rule does not age a resource from its
creation time alone - it uses the later of the resource's relevant timestamps:

    reference_time_utc = max(CreationTime, LastModifiedTime)
    age_days = floor((now_utc - reference_time_utc) / 86400)

(docs/specs/aws/ai/sagemaker_endpoint_idle.md section 5.1;
cleancloud/providers/aws/rules/ai/sagemaker_endpoint_idle.py, the
reference_time_utc normalization.) A resource changed recently is not old
enough, however long ago it was first created.

ElastiCache replaces a failed node in place, and each CacheNodes entry carries
its own CacheNodeCreateTime. A node created inside the observation window means
part of the cluster has less history than an idle finding would claim, so the
cluster's reference time is that node's create time and the cluster is too
young to evaluate. A node with no usable create time at all cannot be aged, and
the sibling contract sends an unusable timestamp to SKIP ITEM
(docs/specs/aws/rds_idle.md section 5, Normalization requirements).
"""

from ec_mocks import REGION, days_ago, load_rule, make_cluster, make_node, make_session


def test_node_replaced_inside_the_window_blocks_the_finding():
    rule = load_rule()
    cluster = make_cluster(
        cluster_id="cc-newnode",
        create_time=days_ago(40),
        num_nodes=2,
        nodes=[
            make_node("cc-newnode-0001", days_ago(40)),
            make_node("cc-newnode-0002", days_ago(3)),
        ],
    )
    assert rule(make_session([cluster]), REGION) == [], (
        "a node replaced three days ago gives the cluster a three-day "
        "reference time, so it is too young to evaluate"
    )


def test_node_missing_create_time_blocks_the_finding():
    rule = load_rule()
    cluster = make_cluster(
        cluster_id="cc-no-node-ct",
        create_time=days_ago(40),
        num_nodes=1,
        nodes=[{"CacheNodeId": "cc-no-node-ct-0001", "CacheNodeStatus": "available"}],
    )
    assert rule(make_session([cluster]), REGION) == [], (
        "a node with no usable CacheNodeCreateTime cannot be aged"
    )
