"""Safety: an API failure must FAIL THE RULE, never be swallowed.

docs/specs/aws/rds_idle.md section 10 ("Failure Model") lists inventory
pagination failure, CloudWatch retrieval failure and permission failure as
rule-level failures. A swallowed error turns an unmeasured account into a
silent clean bill of health, or into findings built on nothing.
"""

import pytest
from botocore.exceptions import ClientError

from ec_mocks import REGION, client_error, load_rule, make_cluster, make_session


def test_cloudwatch_failure_fails_the_rule():
    rule = load_rule()
    session = make_session(
        [make_cluster(cluster_id="cc-cwfail")], cw_error=client_error("InternalFailure")
    )
    with pytest.raises((ClientError, PermissionError)):
        rule(session, REGION)


def test_cloudwatch_access_denied_fails_the_rule():
    rule = load_rule()
    session = make_session(
        [make_cluster(cluster_id="cc-denied")], cw_error=client_error("AccessDenied")
    )
    # Either the raw ClientError or the repo's PermissionError degradation is
    # acceptable; silently continuing is not.
    with pytest.raises((ClientError, PermissionError)):
        rule(session, REGION)


def test_describe_cache_clusters_failure_fails_the_rule():
    rule = load_rule()
    session = make_session(
        [make_cluster(cluster_id="cc-listfail")],
        describe_error=client_error("InternalFailure"),
    )
    with pytest.raises((ClientError, PermissionError)):
        rule(session, REGION)
