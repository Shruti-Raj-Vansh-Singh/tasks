"""Offline boto3 mocks for the aws.elasticache.cluster.idle hidden suites.

No network and no credentials: every AWS interaction is served by the fakes
below, the same offline convention the repo's own AWS rule tests use.

Fixture physics - one consistent world across the visible and hidden suites:

  * The cache COMMAND family (CacheHits, CacheMisses) reads zero on a cluster
    carrying no client workload.
  * The traffic / session / storage series (NetworkBytesIn, NetworkBytesOut,
    CurrConnections, BytesUsedForCache) keep the nonzero internal baseline a
    running cluster always reports. instruction.md states that baseline as a
    provider fact, so an implementation that queries them for corroboration
    must not read the baseline as client activity.
  * The cluster-aggregate dimension is DERIVED from the per-node values, never
    contradicted: aggregate = max over nodes. A world where the aggregate reads
    zero while a node is serving traffic cannot occur in CloudWatch, so no
    scenario builds one. Whichever dimension an implementation queries, it sees
    a world that could really happen.
  * A metric this harness was not asked about reads zero. Only the explicit
    NO_DATA sentinel models "CloudWatch returned nothing", so querying an extra
    corroborating series is never punished as missing telemetry.
"""

from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock

from botocore.exceptions import ClientError

REGION = "us-east-1"

# Sentinel: this series must come back with an empty Datapoints list.
NO_DATA = object()

COMMAND_METRICS = ("CacheHits", "CacheMisses")

# The nonzero internal baseline a running cluster always reports.
_BASELINE = {
    "NetworkBytesIn": 512.0,
    "NetworkBytesOut": 512.0,
    "CurrConnections": 1.0,
    "NewConnections": 1.0,
    "BytesUsedForCache": 1048576.0,
    "ReplicationBytes": 128.0,
}


def now():
    return datetime.now(timezone.utc)


def days_ago(n):
    return now() - timedelta(days=n)


def client_error(code="InternalFailure"):
    return ClientError({"Error": {"Code": code, "Message": code}}, "DescribeOp")


def make_node(node_id, create_time=None):
    return {
        "CacheNodeId": node_id,
        "CacheNodeStatus": "available",
        "CacheNodeCreateTime": create_time if create_time is not None else days_ago(30),
    }


def make_cluster(
    cluster_id="cc-idle",
    status="available",
    engine="redis",
    engine_version="7.1",
    node_type="cache.t3.micro",
    num_nodes=1,
    create_time=None,
    replication_group_id=None,
    nodes=None,
):
    """A DescribeCacheClusters item in ShowCacheNodeInfo=True shape.

    Defaults describe a cleanly idle, fully evidenced standalone cluster:
    available, 30 days old, one node created 30 days ago.
    """
    if create_time is None:
        create_time = days_ago(30)
    if nodes is None:
        nodes = [
            make_node("%s-%04d" % (cluster_id, i), days_ago(30))
            for i in range(1, num_nodes + 1)
        ]
    cluster = {
        "CacheClusterId": cluster_id,
        "CacheClusterStatus": status,
        "Engine": engine,
        "EngineVersion": engine_version,
        "CacheNodeType": node_type,
        "NumCacheNodes": num_nodes,
        "CacheClusterCreateTime": create_time,
        "CacheNodes": list(nodes),
    }
    if replication_group_id is not None:
        cluster["ReplicationGroupId"] = replication_group_id
    return cluster


def commands(**per_node):
    """Build a per-node command table: node_id -> {metric: value}.

    A value may be a number or the NO_DATA sentinel. Any node or metric not
    named reads zero.
    """
    table = {}
    for node_id, spec in per_node.items():
        table[node_id] = dict(spec)
    return table


class _Paginator:
    def __init__(self, pages, key, error=None):
        self._pages = pages
        self._key = key
        self._error = error

    def paginate(self, **kwargs):
        if self._error is not None:
            raise self._error
        for page in self._pages:
            yield {self._key: page}


def make_session(
    clusters,
    node_metrics=None,
    cluster_pages=None,
    describe_error=None,
    cw_error=None,
):
    """Build a MagicMock boto3 Session wired for ElastiCache + CloudWatch.

    ``node_metrics`` maps cluster_id -> node_id -> metric -> value. Anything
    unlisted reads zero. The cluster-aggregate dimension is computed as the max
    over that cluster's nodes, so the aggregate can never disagree with the
    nodes underneath it.

    ``cluster_pages`` supplies explicit pagination; when given it replaces
    ``clusters`` as the inventory source.
    """
    node_metrics = node_metrics or {}
    pages = cluster_pages if cluster_pages is not None else [list(clusters)]
    inventory = [item for page in pages for item in page]

    elasticache = MagicMock()
    cloudwatch = MagicMock()

    def get_paginator(operation_name):
        if operation_name == "describe_cache_clusters":
            return _Paginator(pages, "CacheClusters", describe_error)
        raise ValueError("Unexpected paginator: %s" % operation_name)

    elasticache.get_paginator.side_effect = get_paginator

    def describe_cache_clusters(**kwargs):
        if describe_error is not None:
            raise describe_error
        return {"CacheClusters": list(inventory)}

    elasticache.describe_cache_clusters.side_effect = describe_cache_clusters

    def _node_ids(cluster_id):
        for item in inventory:
            if item.get("CacheClusterId") == cluster_id:
                return [
                    node.get("CacheNodeId")
                    for node in item.get("CacheNodes", [])
                    if isinstance(node, dict)
                ]
        return []

    def _value(cluster_id, node_id, metric):
        per_cluster = node_metrics.get(cluster_id, {})
        if node_id is not None:
            spec = per_cluster.get(node_id, {})
            if metric in spec:
                return spec[metric]
            if metric in _BASELINE:
                return _BASELINE[metric]
            return 0.0
        # Cluster-aggregate dimension: derived from the nodes, never contrary.
        observed = []
        for candidate in _node_ids(cluster_id):
            spec = per_cluster.get(candidate, {})
            if metric in spec:
                observed.append(spec[metric])
            elif metric in _BASELINE:
                observed.append(_BASELINE[metric])
            else:
                observed.append(0.0)
        numeric = [v for v in observed if v is not NO_DATA]
        if not numeric:
            return NO_DATA if observed else 0.0
        return max(numeric)

    def get_metric_statistics(**kwargs):
        if cw_error is not None:
            raise cw_error
        dims = {d["Name"]: d["Value"] for d in kwargs.get("Dimensions", [])}
        value = _value(
            dims.get("CacheClusterId"), dims.get("CacheNodeId"), kwargs.get("MetricName")
        )
        if value is NO_DATA:
            return {"Datapoints": []}
        return {"Datapoints": [{"Maximum": float(value), "Timestamp": now()}]}

    cloudwatch.get_metric_statistics.side_effect = get_metric_statistics

    session = MagicMock()

    def client(service_name, **kwargs):
        if service_name == "elasticache":
            return elasticache
        if service_name == "cloudwatch":
            return cloudwatch
        raise ValueError("Unexpected service: %s" % service_name)

    session.client.side_effect = client
    session._elasticache = elasticache
    session._cloudwatch = cloudwatch
    return session


def load_rule():
    """Import the entrypoint under test, failing loudly if it is absent."""
    from cleancloud.providers.aws.rules.elasticache_idle import (
        find_idle_elasticache_clusters,
    )

    return find_idle_elasticache_clusters
