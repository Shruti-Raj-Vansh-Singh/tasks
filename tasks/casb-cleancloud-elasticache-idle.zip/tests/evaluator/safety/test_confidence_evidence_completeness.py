"""Safety: the top tier requires COMPLETE evidence.

Confidence is not decoration on this platform. docs/confidence.md documents the
top tier as the one enforcement acts on - "Enforcement gates (optional) - fail a
scheduled job or PR scan if HIGH confidence waste exceeds a threshold" - and
requires "strong, deterministic signals" for it. Claiming it on evidence the
rule never obtained can fail a pipeline over a cluster nobody measured.

The repository's only per-sub-resource idle rule gates promotion on exactly this
question - whether every sub-resource actually reported:

    confidence = ConfidenceLevel.HIGH if all_had_datapoints else ConfidenceLevel.MEDIUM
        cleancloud/providers/aws/rules/ai/sagemaker_endpoint_idle.py

and docs/rules/aws.md states it in words for that rule: "HIGH (all variants
confirmed zero traffic); MEDIUM (at least one variant missing datapoints)".

This is a ceiling, not an exclusion: the finding is still emitted. Suppressing
the cluster instead is a defensible reading of the sibling contract and is NOT
graded here - the check skips when there is no finding to grade.
"""

import pytest

from ec_mocks import NO_DATA, REGION, commands, load_rule, make_cluster, make_session


def _only(findings, resource_id):
    matches = [f for f in findings if f.resource_id == resource_id]
    if not matches:
        pytest.skip(
            "rule emitted no finding for %s; confidence tier is not gradeable "
            "(suppression is graded by the utility suite)" % resource_id
        )
    return matches[0]


def test_partial_node_datapoints_cap_confidence_below_top_tier():
    rule = load_rule()
    cluster = make_cluster(cluster_id="cc-partial", num_nodes=2)
    session = make_session(
        [cluster],
        node_metrics={
            "cc-partial": commands(
                **{
                    "cc-partial-0001": {"CacheHits": 0.0, "CacheMisses": 0.0},
                    "cc-partial-0002": {"CacheHits": NO_DATA, "CacheMisses": NO_DATA},
                }
            )
        },
    )
    finding = _only(rule(session, REGION), "cc-partial")
    assert finding.confidence.value != "high", (
        "one node returned no datapoints, so the evidence is incomplete and "
        "cannot support the tier enforcement gates act on"
    )


def test_complete_standalone_evidence_is_not_downgraded_to_low():
    """The ceiling is a ceiling, not a blanket demotion.

    A fully evidenced standalone cluster must not be reported at LOW - the
    sibling contract forbids emitting LOW findings at all (rds_idle.md section
    12), and an implementation that answers every uncertainty with LOW has
    stopped discriminating.
    """
    rule = load_rule()
    finding = _only(rule(make_session([make_cluster(cluster_id="cc-clean")]), REGION), "cc-clean")
    assert finding.confidence.value != "low"
