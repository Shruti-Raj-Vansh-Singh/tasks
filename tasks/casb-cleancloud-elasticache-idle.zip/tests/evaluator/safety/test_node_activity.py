"""Safety: observed activity on ANY cache node blocks the cluster finding.

The repository's per-sub-resource idle rule skips the item as soon as one
sub-resource shows traffic - "any evaluated variant has positive Invocations
Sum" is an exclusion in
cleancloud/providers/aws/rules/ai/sagemaker_endpoint_idle.py, and
docs/rules/aws.md states the detection as zero invocations "across all
billable production variants".

An implementation that measures one node, or stops at the first quiet reading,
reports a cluster that is actively serving clients as an idle cleanup
candidate. Note the fixture is internally consistent: the cluster-aggregate
series reflects the busy node exactly as CloudWatch would, so an
implementation that queries the aggregate dimension also sees the activity.
Only evaluating a SUBSET of the nodes fails this check.
"""

from ec_mocks import REGION, commands, load_rule, make_cluster, make_session


def test_active_second_node_blocks_the_finding():
    rule = load_rule()
    cluster = make_cluster(cluster_id="cc-hot", num_nodes=3)
    session = make_session(
        [cluster],
        node_metrics={
            "cc-hot": commands(
                **{
                    "cc-hot-0001": {"CacheHits": 0.0, "CacheMisses": 0.0},
                    "cc-hot-0002": {"CacheHits": 4321.0, "CacheMisses": 12.0},
                    "cc-hot-0003": {"CacheHits": 0.0, "CacheMisses": 0.0},
                }
            )
        },
    )
    assert rule(session, REGION) == [], (
        "a cluster with a node serving 4321 cache hits is not idle"
    )


def test_active_last_node_blocks_the_finding():
    rule = load_rule()
    cluster = make_cluster(cluster_id="cc-tail", num_nodes=3)
    session = make_session(
        [cluster],
        node_metrics={
            "cc-tail": commands(**{"cc-tail-0003": {"CacheMisses": 87.0}})
        },
    )
    assert rule(session, REGION) == []
