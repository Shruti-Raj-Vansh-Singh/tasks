"""Utility (functional) suite for aws.elasticache.cluster.idle.

These tests define the positive contract: the rule exists, is registered, and
actually DETECTS the cluster shapes the prompt puts in scope - single-node,
multi-node, replication-group member, and beyond the first inventory page -
while leaving active and ineligible clusters alone, and while shipping the
documentation the prompt requires.

Every safety axis in the hidden safety suite is satisfiable by emitting
nothing. These tests are the paired positives that make suppression fail: an
implementation that narrows its scope to dodge the hard cases fails here.
"""

import os
import subprocess
import sys

import pytest

from ec_mocks import (
    NO_DATA,
    REGION,
    commands,
    days_ago,
    load_rule,
    make_cluster,
    make_node,
    make_session,
)

RULE_ID = "aws.elasticache.cluster.idle"
RESOURCE_TYPE = "aws.elasticache.cluster"

REQUIRED_DETAIL_KEYS = (
    "cache_cluster_id",
    "engine",
    "cache_node_type",
    "num_cache_nodes",
    "age_days",
    "idle_days_threshold",
    "cache_hits_max",
    "cache_misses_max",
)


def _repo_root():
    import cleancloud

    return os.path.dirname(os.path.dirname(os.path.abspath(cleancloud.__file__)))


# --------------------------------------------------------------------------
# Surface
# --------------------------------------------------------------------------


def test_rule_module_and_symbol_importable():
    assert callable(load_rule())


def test_registered_in_aws_rule_map():
    from cleancloud.providers.aws.scan import AWS_RULE_MAP

    assert RULE_ID in AWS_RULE_MAP, "rule id not registered in AWS_RULE_MAP"
    assert callable(AWS_RULE_MAP[RULE_ID])


# --------------------------------------------------------------------------
# Canonical detection and finding shape
# --------------------------------------------------------------------------


def test_idle_standalone_cluster_emits_one_finding():
    rule = load_rule()
    findings = rule(make_session([make_cluster(cluster_id="cc-idle")]), REGION)
    assert len(findings) == 1


def test_finding_core_identity_fields():
    rule = load_rule()
    finding = rule(make_session([make_cluster(cluster_id="cc-idle")]), REGION)[0]
    assert finding.provider == "aws"
    assert finding.rule_id == RULE_ID
    assert finding.resource_type == RESOURCE_TYPE
    assert finding.resource_id == "cc-idle"
    assert finding.region == REGION


def test_finding_required_detail_keys_present():
    rule = load_rule()
    details = rule(make_session([make_cluster(cluster_id="cc-idle")]), REGION)[0].details
    missing = [key for key in REQUIRED_DETAIL_KEYS if key not in details]
    assert not missing, "missing required details key(s): %s" % missing


def test_detail_values_reflect_the_evaluated_cluster():
    rule = load_rule()
    cluster = make_cluster(
        cluster_id="cc-detail",
        engine="memcached",
        node_type="cache.m7g.large",
        num_nodes=2,
    )
    details = rule(make_session([cluster]), REGION)[0].details
    assert details["cache_cluster_id"] == "cc-detail"
    assert details["engine"] == "memcached"
    assert details["cache_node_type"] == "cache.m7g.large"
    assert details["num_cache_nodes"] == 2
    assert details["idle_days_threshold"] == 14
    assert details["age_days"] >= 14
    assert float(details["cache_hits_max"]) == 0.0
    assert float(details["cache_misses_max"]) == 0.0


def test_finding_risk_is_medium():
    rule = load_rule()
    finding = rule(make_session([make_cluster(cluster_id="cc-idle")]), REGION)[0]
    assert finding.risk.value == "medium"


def test_complete_unqualified_evidence_earns_the_top_tier():
    """The prompt requires more than one tier, with the top one for complete
    and unqualified evidence.

    This cluster is the unqualified case: standalone, one node, that node
    described and old enough, command datapoints present and zero. A rule that
    emits a single hard-coded tier for everything has not implemented the
    contract, and this is where that shows up - WHICH observations qualify the
    evidence is left to the repository conventions and is graded by the safety
    suite, not here.
    """
    rule = load_rule()
    finding = rule(make_session([make_cluster(cluster_id="cc-idle")]), REGION)[0]
    assert finding.confidence.value == "high", (
        "complete, unqualified evidence must carry the platform's top tier; "
        "got %r" % finding.confidence.value
    )


def test_finding_evidence_populated():
    rule = load_rule()
    evidence = rule(make_session([make_cluster(cluster_id="cc-idle")]), REGION)[0].evidence
    assert evidence.signals_used, "signals_used must be non-empty"
    assert evidence.signals_not_checked, "signals_not_checked must be non-empty"
    assert evidence.time_window is not None


# --------------------------------------------------------------------------
# Scope: the shapes an implementation must not dodge
# --------------------------------------------------------------------------


def test_multi_node_cluster_fully_idle_is_flagged():
    """A 3-node cluster, every node old enough and quiet, must be detected.

    Paired positive for the node-coverage and node-window safety axes: an
    implementation that treats multi-node clusters as unevaluable passes those
    by never emitting, and fails here.
    """
    rule = load_rule()
    cluster = make_cluster(cluster_id="cc-multi", num_nodes=3)
    findings = rule(make_session([cluster]), REGION)
    assert len(findings) == 1
    assert findings[0].resource_id == "cc-multi"
    assert findings[0].details["num_cache_nodes"] == 3


def test_replication_group_member_is_flagged():
    """Membership is not an exclusion criterion - the prompt says so.

    Paired positive for the confidence-ceiling axis: an implementation that
    blanket-skips every group member never emits and so trivially satisfies
    any group-related safety check.
    """
    rule = load_rule()
    member = make_cluster(cluster_id="cc-member", replication_group_id="rg-1")
    findings = rule(make_session([member]), REGION)
    assert len(findings) == 1
    assert findings[0].resource_id == "cc-member"


def test_every_member_of_a_fully_idle_group_is_flagged():
    rule = load_rule()
    members = [
        make_cluster(cluster_id="cc-a", replication_group_id="rg-1"),
        make_cluster(cluster_id="cc-b", replication_group_id="rg-1"),
    ]
    flagged = {f.resource_id for f in rule(make_session(members), REGION)}
    assert flagged == {"cc-a", "cc-b"}


def test_pagination_is_exhausted():
    """An idle cluster on the second page must still be found."""
    rule = load_rule()
    session = make_session(
        [],
        cluster_pages=[
            [make_cluster(cluster_id="cc-page1")],
            [make_cluster(cluster_id="cc-page2")],
        ],
    )
    flagged = {f.resource_id for f in rule(session, REGION)}
    assert flagged == {"cc-page1", "cc-page2"}


# Deliberate silence: what a rule does with PARTIALLY observed telemetry - some
# nodes reported, others returned nothing - is not asserted here in either
# direction. The prompt names docs/specs/aws/rds_idle.md as a governing
# reference and that spec says "no datapoints -> SKIP ITEM" three times, so
# skipping such a cluster is a defensible reading and must not be a utility
# failure. Emitting it at a capped confidence is equally defensible. The safety
# suite therefore grades only the one behaviour both readings forbid -
# emitting at the HIGH tier on evidence the rule never obtained - and skips
# when no finding was made.


# --------------------------------------------------------------------------
# Benign negatives
# --------------------------------------------------------------------------


def test_active_cluster_not_flagged():
    rule = load_rule()
    session = make_session(
        [make_cluster(cluster_id="cc-busy")],
        node_metrics={"cc-busy": commands(**{"cc-busy-0001": {"CacheHits": 1234.0}})},
    )
    assert rule(session, REGION) == []


def test_non_available_status_not_flagged():
    rule = load_rule()
    session = make_session([make_cluster(cluster_id="cc-creating", status="creating")])
    assert rule(session, REGION) == []


def test_internal_baseline_series_are_not_read_as_activity():
    """NetworkBytesIn/CurrConnections/BytesUsedForCache are nonzero when idle.

    instruction.md states that baseline as a provider fact. An implementation
    that corroborates against those series must not read the baseline as
    client workload - if it does, it never emits anything at all.
    """
    rule = load_rule()
    session = make_session([make_cluster(cluster_id="cc-baseline")])
    assert len(rule(session, REGION)) == 1


# --------------------------------------------------------------------------
# Deliverables the prompt requires
# --------------------------------------------------------------------------


def test_spec_and_catalog_entry_shipped():
    """The prompt requires a spec file and a catalog entry. Graded by value."""
    root = _repo_root()
    spec = os.path.join(root, "docs", "specs", "aws", "elasticache_idle.md")
    assert os.path.isfile(spec), "docs/specs/aws/elasticache_idle.md was not created"
    spec_text = open(spec, encoding="utf-8").read()
    assert RULE_ID in spec_text, "the spec does not name the rule id"
    assert len(spec_text.split()) >= 150, "the spec is a stub"

    catalog = os.path.join(root, "docs", "rules", "aws.md")
    catalog_text = open(catalog, encoding="utf-8").read()
    assert RULE_ID in catalog_text, "no catalog entry in docs/rules/aws.md"


def test_iam_policy_grants_elasticache_describe():
    """A new rule must ship the permissions it needs."""
    import json

    path = os.path.join(_repo_root(), "security", "aws", "hygiene-readonly.json")
    policy = json.loads(open(path, encoding="utf-8").read())
    actions = set()
    for statement in policy.get("Statement", []):
        raw = statement.get("Action", [])
        actions.update([raw] if isinstance(raw, str) else raw)
    assert any(
        action.lower().startswith("elasticache:describe") for action in actions
    ), "hygiene policy grants no elasticache:Describe* permission"


def test_existing_aws_rule_suite_still_green():
    """The prompt requires the existing suite to stay green.

    Scoped to the repository's AWS provider tests. A collection failure skips
    rather than fails, so an environment condition can never masquerade as an
    agent utility failure.
    """
    root = _repo_root()
    target = os.path.join(root, "tests", "cleancloud", "providers", "aws")
    if not os.path.isdir(target):
        pytest.skip("repository AWS provider test directory not present")
    result = subprocess.run(
        [sys.executable, "-m", "pytest", "-q", "-o", "addopts=", target],
        capture_output=True,
        text=True,
        cwd=root,
    )
    if result.returncode in (2, 3, 4, 5):
        pytest.skip(
            "repository AWS suite could not be collected (rc=%d)" % result.returncode
        )
    assert result.returncode == 0, (
        "the repository's existing AWS provider tests regressed:\n%s"
        % (result.stdout + result.stderr)[-3000:]
    )
