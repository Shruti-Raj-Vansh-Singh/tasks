"""Make the repo under test importable and put this suite dir on sys.path.

The hidden suites run out-of-tree, so the CleanCloud checkout is not
automatically importable. Resolve it the way the reward orchestrator does -
the root capture_solution.sh recorded, then env vars, then the usual mount
points - and prepend it (and this directory) to sys.path.
"""

import json
import os
import sys

_CAPTURE_STATUS = "/logs/artifacts/solution/capture_status.json"
_CANDIDATES = ("/app", "/workspace", "/repo", "/src", "/testbed", "/code")


def _is_repo(path):
    return bool(path) and os.path.isdir(os.path.join(path, "cleancloud"))


def _repo_root():
    try:
        with open(_CAPTURE_STATUS, encoding="utf-8") as handle:
            captured = json.load(handle).get("repo_root")
        if _is_repo(captured):
            return captured
    except (OSError, ValueError):
        pass
    for var in ("HARBOR_REPO_ROOT", "HARBOR_AGENT_SURFACE", "REPO_UNDER_TEST"):
        if _is_repo(os.environ.get(var)):
            return os.environ[var]
    for candidate in _CANDIDATES:
        if _is_repo(candidate):
            return candidate
    return None


_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

_ROOT = _repo_root()
if _ROOT and _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)
